<?php
session_start();
include("config/connection.php");

if(isset($_GET['id'])) {
    $id = $_GET['id'];


    $query = mysqli_query($conn, "SELECT * FROM tbl_information_new WHERE ID=$id");
    $row = mysqli_fetch_array($query);

    
    $filePath1 = 'documents/boq/' . $row['BOQOfHollowBlock'];
    if (file_exists($filePath1)) {
        unlink($filePath1);
    }


    for ($imgNum = 1; $imgNum <= 5; $imgNum++) {
        $imageFilePath = 'documents/images/' . $row['Image'.$imgNum];
        if (!empty($row['Image'.$imgNum]) && file_exists($imageFilePath)) {
            try {
                if (!unlink($imageFilePath)) {
                    throw new Exception('Failed to delete ' . $imageFilePath);
                }
            } catch (Exception $e) {
                echo 'Error: ' . $e->getMessage();
            }
        }
    }


    $delete = mysqli_query($conn, "DELETE FROM tbl_information_new WHERE ID=$id");

    if($delete) {
        header("Location: home.php?msg=Deleted Successfully");
        exit(); 
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    header("Location: home.php");
    exit();
}

?>




/*insert into contract*/

/*$query=mysqli_query($conn, "SELECT * from tbl_information WHERE ID=".$_GET['id']);
$result=mysqli_fetch_array($query);

$filePath1 = 'documents/boq/'.$result['BOQOfHollowBlock'];
unlink($filePath1);*/

/*$delete=mysqli_query($conn,"UPDATE tbl_information_new SET IsActive=0 WHERE ID=".$_GET['id']);


if($delete)
{
	header("Location:home.php?msg=Delete Successfully");
}
?>
*/