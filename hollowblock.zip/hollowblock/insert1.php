<?php
session_start();
include("config/connection.php");
/*insert into contract*/


$query=mysqli_query($conn, "SELECT ID from tbl_information_new ORDER BY ID DESC LIMIT 1");
$result=mysqli_fetch_array($query);
$lastID=$result['ID']+1;


$fileName3 = $lastID."-".$_FILES['BOQOfHollowBlock']['name']; //rename image
$fileTmpName = $_FILES['BOQOfHollowBlock']['tmp_name'];
$fileType = $_FILES['BOQOfHollowBlock']['type'];
$fileExt = explode('.', $fileName3);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png','csv','xsl','xlsx');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/boq/';
$result = move_uploaded_file($fileTmpName, $directory.$fileName3);
$file3=$fileName3; 
}
else $file3='';

$target_dir = "documents/images/";
	$target_file1 = $target_dir . basename($_FILES["Image1"]["name"]);
	$target_file2 = $target_dir . basename($_FILES["Image2"]["name"]);
	$target_file3 = $target_dir . basename($_FILES["Image3"]["name"]);
	$target_file4 = $target_dir . basename($_FILES["Image4"]["name"]);
	$target_file5 = $target_dir . basename($_FILES["Image5"]["name"]);
	
	
	$imageName1 = $_FILES['Image1']['name'];
	$imageName2 = $_FILES['Image2']['name'];
	$imageName3 = $_FILES['Image3']['name'];
	$imageName4 = $_FILES['Image4']['name'];
	$imageName5 = $_FILES['Image5']['name'];
			
			
	$imageTmpName1 = $_FILES['Image1']['tmp_name'];
	$imageTmpName2 = $_FILES['Image2']['tmp_name'];
	$imageTmpName3 = $_FILES['Image3']['tmp_name'];
	$imageTmpName4 = $_FILES['Image4']['tmp_name'];
	$imageTmpName5 = $_FILES['Image5']['tmp_name'];
	
	$fileSize1 = $_FILES['Image1']['size'];
	$fileSize2 = $_FILES['Image2']['size'];
	$fileSize3 = $_FILES['Image3']['size'];
	$fileSize4 = $_FILES['Image4']['size'];
	$fileSize5 = $_FILES['Image5']['size'];
	
	$fileType1 = $_FILES['Image1']['type'];
	$fileType2 = $_FILES['Image2']['type'];
	$fileType3 = $_FILES['Image3']['type'];
	$fileType4 = $_FILES['Image4']['type'];
	$fileType5 = $_FILES['Image5']['type'];
			
	$fileExt1 = explode('.', $imageName1);
	$fileExt2 = explode('.', $imageName2);
	$fileExt3 = explode('.', $imageName3);
	$fileExt4 = explode('.', $imageName4);
	$fileExt5 = explode('.', $imageName5);

	$fileActualExt1 = strtolower(end($fileExt1));
	$fileActualExt2 = strtolower(end($fileExt2));
	$fileActualExt3 = strtolower(end($fileExt3));
	$fileActualExt4 = strtolower(end($fileExt4));
	$fileActualExt5 = strtolower(end($fileExt5));

    $allowed = array('doc','docx','pdf','jpg','jpeg','png');
			
	if(($target_file1 != "documents/images/") && in_array($fileActualExt1, $allowed)){
		move_uploaded_file($_FILES["Image1"]["tmp_name"], $target_file1);
	}else{
		$target_file1 = null;
	}
	if(($target_file2 != "documents/images/") && in_array($fileActualExt2, $allowed)){
		move_uploaded_file($_FILES["Image2"]["tmp_name"], $target_file2);
	}else{
		$target_file2 = null;
	}
	if(($target_file3 != "documents/images/") && in_array($fileActualExt3, $allowed)){
		move_uploaded_file($_FILES["Image3"]["tmp_name"], $target_file3);
	}else{
		$target_file3 = null;
	}
	if(($target_file4 != "documents/images/") && in_array($fileActualExt4, $allowed)){
		move_uploaded_file($_FILES["Image4"]["tmp_name"], $target_file4);
	}else{
		$target_file4 = null;
	}
	if(($target_file5 != "documents/images/") && in_array($fileActualExt5, $allowed)){
		move_uploaded_file($_FILES["Image5"]["tmp_name"], $target_file5);
	}else{
		$target_file5 = null;
	}


$query="INSERT INTO tbl_information_new SET
		OfficeID=".$_SESSION['OfficeID'].",
		FinancialYear='".$_POST['FinancialYear']."',
		NameOfTender='".$_POST['NameOfTender']."',
		TenderAmount='".$_POST['TenderAmount']."',
		BOQOfHollowBlock='".$file3."',
		WorkDone='".$_POST['WorkDone']."',
		QuntOf10Inch='".$_POST['QuntOf10Inch']."',
		QuntOf10InchBlock='".$_POST['QuntOf10InchBlock']."',
		OuntOf10Inchfired='".$_POST['OuntOf10Inchfired']."',
		ProOf10InchBlock='".$_POST['ProOf10InchBlock']."',
		ReaOf10InchFired='".$_POST['ReaOf10InchFired']."',
		QuntOf5Inch='".$_POST['QuntOf5Inch']."',
		QuntOf5InchBlock='".$_POST['QuntOf5InchBlock']."',
		OuntOf5Inchfired='".$_POST['OuntOf5Inchfired']."',
		ProOf5InchBlock='".$_POST['ProOf5InchBlock']."',
		ReaOf5InchFired='".$_POST['ReaOf5InchFired']."',
		QuntOfHering='".$_POST['QuntOfHering']."',
		QuntOfHeringBlock='".$_POST['QuntOfHeringBlock']."',
		OuntOfHeringfired='".$_POST['OuntOfHeringfired']."',
		ProOfHeringBlock='".$_POST['ProOfHeringBlock']."',
		ReaOfHeringFired='".$_POST['ReaOfHeringFired']."',
		Image1='".$target_file1."',
		Image2='".$target_file2."',
		Image3='".$target_file3."',
		Image4='".$target_file4."',
		Image5='".$target_file5."',
		Image1Caption='".$_POST['Image1Caption']."',
		Image2Caption='".$_POST['Image2Caption']."',
		Image3Caption='".$_POST['Image3Caption']."',
		Image4Caption='".$_POST['Image4Caption']."',
		Image5Caption='".$_POST['Image5Caption']."',
		InsertDate='".date('Y-m-d')."',
		OrderID=".$lastID;
		
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
		
if($result)
{
	header("Location: home.php?msg=Information Added Successfully");
}

?>