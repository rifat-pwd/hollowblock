<?php 
session_start();
if ($_SESSION['flag']=='ok') {
include("config/connection.php");

header("Content-type: application/vnd.ms-excel; name='excel'");
header("Content-Disposition: attachment; filename=hollow-info.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (ERP) for Co-ordination</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php //include 'css_master.php';?>

</head>

<body>


    

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php //include 'navbar.php';?>
        
        <?php 
		$result = mysqli_query($conn, "SELECT ".DBHR.".hrtoffice.OfficeName FROM ".DBHR.".hrtoffice 
								WHERE ".DBHR.".hrtoffice.OfficeID=".$_GET['officeid'])or die(mysqli_error($conn));
	    $row=mysqli_fetch_array($result);
	   ?>

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $row['OfficeName'];?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
            
         <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">Uses of Hollow Block / Concrete / Sand Cement Block / Non Fired Bricks</strong> 
                            </div>
                       <div class="card-body">
                      <table  style="font-size:12px; width:1200px; border:1px solid #000;" border="1">
                                    <thead>
                                        <tr>
                                        <th>ক্রম</th>
                                        <th>অর্থ বছর</th>
                                        <th>কাজের নাম</th>
                                        <th>কাজের মূল্য(লক্ষ্য টাকায়)</th>
                                        <th>কাজটি সমাপ্ত কিনা?</th>
                                        <th>টেন্ডারে ১০'' ব্লকের গাথুনী (m3)</th>
                                        <th>টেন্ডারে Non Fired ব্লকের গাথুনী (m3)</th>
                                        <th>টেন্ডারে Fired Brick এর গাথুনী (m3)</th>
                                        <th>Non Fired ব্লক ব্যবহারের বাস্তবায়নের অগ্রগতি (m3)</th>
                                        <th>Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা</th>
                                        <th>টেন্ডারে ৫'' মোট গাথুনী (sqm)</th>
                                        <th>টেন্ডারে ৫'' Non Fired ব্লকের গাথুনী (sqm)</th>
                                        <th>টেন্ডারে ৫'' Fired Brick এর গাথুনী (sqm)</th>
                                        <th>Non Fired ব্লক ব্যবহারের বাস্তবায়নের অগ্রগতি (sqm)</th>
                                        <th>Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা</th>
                                        <th>টেন্ডারে রাস্তায় ব্লকের এবং ইটের পরিমান (sqm)</th>
                                        <th>টেন্ডারে রাস্তায় Non Fired ব্লকের পরিমান (sqm)</th>
                                        <th>টেন্ডারে রাস্তায় Fired Brick এর পরিমান (sqm)</th>
                                        <th>Non Fired ব্লক ব্যবহারের বাস্তবায়নের অগ্রগতি (Sqm)</th>
                                        <th>Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
					
					/* where tbl_case.OfficeID=".$_SESSION['OfficeID'] */
                    $sl = 0;
					$query="SELECT * from tbl_information_new where OfficeID='".$_GET['officeid']."'";
                    $query1 = mysqli_query($conn,$query) or die(mysqli_error($conn));
                    while($row=mysqli_fetch_array($query1)){
                        $sl++; 
					echo "<tr>";
					echo "<td>".$i."</td>";
					echo "<td>".$row['FinancialYear']."</td>";
					echo "<td>".$row['NameOfTender']."</td>";
					echo "<td>".$row['TenderAmount']."</td>";
					if($row['WorkDone']==0) echo "<td>না</td>";
					if($row['WorkDone']==1) echo "<td>হ্যা</td>";
					echo "<td>".$row['QuntOf10Inch']."</td>";
					echo "<td>".$row['QuntOf10InchBlock']."</td>";
					echo "<td>".$row['OuntOf10Inchfired']."</td>";
					echo "<td>".$row['ProOf10InchBlock']."</td>";
					echo "<td>".$row['ReaOf10InchFired']."</td>";
					echo "<td>".$row['QuntOf5Inch']."</td>";
					echo "<td>".$row['QuntOf5InchBlock']."</td>";
					echo "<td>".$row['OuntOf5Inchfired']."</td>";
					echo "<td>".$row['ProOf5InchBlock']."</td>";
					echo "<td>".$row['ReaOf5InchFired']."</td>";
					echo "<td>".$row['QuntOfHering']."</td>";
					echo "<td>".$row['QuntOfHeringBlock']."</td>";
					echo "<td>".$row['OuntOfHeringfired']."</td>";
					echo "<td>".$row['ProOfHeringBlock']."</td>";
					echo "<td>".$row['ReaOfHeringFired']."</td>";
					echo "</tr>";

                                   } ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    

    <!-- Right Panel -->


    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
