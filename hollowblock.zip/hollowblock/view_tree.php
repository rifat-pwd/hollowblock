<?php 
session_start();

if ($_SESSION['flag'] == 'ok') {
include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>View Tree Data</title>
    <meta name="description" content="View Data">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <?php include 'css_master.php';?>
    <style>
	
		body table.main-body{
	font-family:Nikosh !important;
	font-size:14px !important;
	font-weight:normal !important;
}


        .space {
            width:100%; 
            height:15px;
        }
        .col-md-3 {
            font-size:12px !important;
        }

    </style>
    
    <script language="javascript" type="text/javascript">
        function confirmDelete() {
        return confirm("Are you sure you want to DELETE the INFORMATION?");
        }
    </script>

</head>

<body>
    <?php include 'sidebar.php';?>
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <?php include 'navbar.php';?>
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong>View Information</strong> 
                    </div>
                    <div class="card-body card-block">
                        <div class="table-responsive">
                            <table class="table table-bordered main-body">
                            <thead>
                                <tr>
                                    <th rowspan="2">ক্রম</th>
                                    <th rowspan="2">রোপনের স্থান</th>
                                    <th colspan="2">গাছের ধরণ</th> 
                                    <th rowspan="2">সংখ্যা</th>
                                    <th rowspan="2">পিচ তৈরী</th>
                                    <th rowspan="2">চারা সংগ্রহ</th>
                                    <th rowspan="2">চারা রোপন</th>
                                    <th rowspan="2">৩০ সেপ্টেম্বর /৩০ ডিসেম্বর/৩০ মার্চে রোপিত গাছের সংখ্যা </th>
                                    <th rowspan="2">মন্তব্য</th>
                                    <th rowspan="2">Action</th>
                                </tr>
                            </thead>
                        <tbody>
                <?php 

$query = mysqli_query($conn, "SELECT * FROM tbl_tree Where IsActive=1 AND OfficeID=".$_SESSION["OfficeID"]) or die(mysqli_error($conn));
$i = 1;
while ($row = mysqli_fetch_array($query)) { ?>
    <tr>
	
	<td><?php echo $i; ?></td>
    <td><?php echo $row['PlaceName']; ?></td>
    <td><?php echo $row['TreeType']; ?></td>
    <td><?php echo $row['TreeVariant']; ?></td>
    <td><?php echo $row['TreeNo']; ?></td>
    <td><?php echo $row['PitchPrepare']; ?></td>
    <td><?php echo $row['SeedCollect']; ?></td>
    <td><?php echo $row['SeedPlant']; ?></td>
    <td><?php echo $row['PlantedNo']; ?></td>
    <td><?php echo $row['Comments']; ?></td>
   <?php
   
    /*echo "<td><a href='view_tree1.php?id=".$row['ID']."' target='_blank' style='color: blue; text-decoration: underline;'>View Images</a></td>";*/
    echo "<td>
    <a href='edit_tree.php?id=".$row['ID']."' style='float:left; color:#00F !important; font-weight:bold; text-decoration:underline;'>Edit</a>
    <br>
    <a href='delete_tree.php?id=".$row['ID']."'  style='float:left; color:#00F !important; font-weight:bold; text-decoration:underline;' onclick='return confirmDelete();'>Delete</a>
    </td>";
    echo "</tr>";
    $i++;
}

?>

                                </tbody>
                            </table>
<!--
                            <a href="home_excel.php"   class="btn btn-violet btn-sm" style="float:left; color:#00F !important; font-weight:bold; text-decoration:underline;">Download Excel</a>
-->                            
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /#right-panel -->
        <!-- Right Panel -->
        <?php include 'js_master.php';?>
        <!-- jQuery script... -->
    </body>
</html>

<?php 
} elseif ($_SESSION["flag"] == "error_pass") {
    $msg = "The password is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "captcha") {
    $msg = "Your given number is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "error_username") {
    $msg = "The username is incorrect!";
    header("Location: index.php?msg=".$msg);
} else {
    $msg = "The username and password are incorrect!";
    header("Location: index.php?msg=".$msg);
}
?>
