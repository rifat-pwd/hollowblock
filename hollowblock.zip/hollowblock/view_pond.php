<?php 
session_start();

if ($_SESSION['flag'] == 'ok') {
include("config/connection.php");

/*if (isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $delete_query = "DELETE FROM tbl_pond WHERE ID = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();
    
    header("Location: view_pond.php?msg=Data deleted successfully");
    exit();
}
*/

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>View Pond Data</title>
    <meta name="description" content="View Data">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <?php include 'css_master.php';?>
    <style>
	
		body table.main-body{
	font-family:Nikosh !important;
	font-size:14px !important;
	font-weight:normal !important;
}


        .space {
            width:100%; 
            height:15px;
        }
        .col-md-3 {
            font-size:12px !important;
        }

    </style>
    
    <script language="javascript" type="text/javascript">
        function confirmDelete() {
        return confirm("Are you sure you want to DELETE the INFORMATION?");
        }
    </script>

</head>

<body>
    <?php include 'sidebar.php';?>
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <?php include 'navbar.php';?>
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong>View Information</strong> 
                    </div>
                    <div class="card-body card-block">
                        <div class="table-responsive">
                            <table class="table table-bordered main-body">
                            <thead>

                                <tr>
                                    <th rowspan="2">ক্রম</th>
                                    <th rowspan="2">জলাশয়, পুকুর, দীঘি, হ্রদ</th>
                                    <th colspan="4">জলাশয় পরিচিতি (হাল বছর)</th>  
                                    <th rowspan="2">পুকুরের আয়তন (দৈর্ঘ্যxপ্রস্থxগভীরতা)</th>
                                    <th rowspan="2">মৎস্য চাষের উপযুক্ততা</th>
                                    <th rowspan="2">মন্তব্য</th>
                                    <th rowspan="2">অনুপযুক্ত হলে করণীয়</th>
                                    <th rowspan="2">ছবি</th>
                                    <th rowspan="2">Action</th>
                                </tr>

                                <tr>
                                    <th>মৌজার নাম</th>
                                    <th>খতিয়ান নং</th>
                                    <th>দাগ নং</th>
                                    <th>জমির পরিমাণ (শতাংশ)</th>
                                    
                                </tr>

                                </thead>
                                <tbody>
                                <?php 
/*$query = "SELECT * FROM tbl_pond";
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
$sl = 0;
while ($result1 = mysqli_fetch_array($result)) {
    $sl++; 
?>
<tr>
    <td><?php echo $sl; ?></td>
    <td><?php echo $result1['PondName']; ?></td>
    <td><?php echo $result1['MouzaName']; ?></td>
    <td><?php echo $result1['KhatianNo']; ?></td>
    <td><?php echo $result1['DagNo']; ?></td>
    <td><?php echo $result1['LandAmount']; ?></td>
    <td><?php echo $result1['PondDimension']; ?></td>
    <td><?php if($result1['SuitableFishery']==1) echo "উপযুক্ত";  else "অনুপযুক্ত"; ?></td>
    <td><?php echo $result1['Comments']; ?></td>
    <td>
        <form action="view_pond.php" method="post" style="display:inline">
            <input type="hidden" name="delete_id" value="<?php echo $result1['ID']; ?>">
            <a href="#" onclick="if(confirm('Are you sure to DELETE the INFORMATION?')) { this.closest('form').submit(); } return false;" style="color: blue; text-decoration: underline;">Delete</a>
        </form>
    </td>

<?php } 
*/

$query = mysqli_query($conn, "SELECT * FROM tbl_pond Where IsActive=1 AND OfficeID=".$_SESSION["OfficeID"]) or die(mysqli_error($conn));
$i = 1;
while ($row = mysqli_fetch_array($query)) { ?>
    <tr>
	
	<td><?php echo $i; ?></td>
    <td><?php echo $row['PondName']; ?></td>
    <td><?php echo $row['MouzaName']; ?></td>
    <td><?php echo $row['KhatianNo']; ?></td>
    <td><?php echo $row['DagNo']; ?></td>
    <td><?php echo $row['LandAmount']; ?></td>
    <td><?php echo $row['PondDimension']; ?></td>
    <td><?php if($row['SuitableFishery']==1) echo "উপযুক্ত";  else echo "অনুপযুক্ত"; ?></td>
    <td><?php echo $row['Comments']; ?></td>
	<td><?php echo $row['ToDo']; ?></td>
	



  
   <?php
   
    echo "<td><a href='view_pond1.php?id=".$row['ID']."' target='_blank' style='color: blue; text-decoration: underline;'>View Images</a></td>";
    echo "<td>
    <a href='edit_pond.php?id=".$row['ID']."' style='float:left; color:#00F !important; font-weight:bold; text-decoration:underline;'>Edit</a>
    <br>
    <a href='delete_pond.php?id=".$row['ID']."'  style='float:left; color:#00F !important; font-weight:bold; text-decoration:underline;' onclick='return confirmDelete();'>Delete</a>
    </td>";
    echo "</tr>";
    $i++;
}

?>

                                </tbody>
                            </table>
<!--
                            <a href="home_excel.php"   class="btn btn-violet btn-sm" style="float:left; color:#00F !important; font-weight:bold; text-decoration:underline;">Download Excel</a>
-->                            
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /#right-panel -->
        <!-- Right Panel -->
        <?php include 'js_master.php';?>
        <!-- jQuery script... -->
    </body>
</html>

<?php 
} elseif ($_SESSION["flag"] == "error_pass") {
    $msg = "The password is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "captcha") {
    $msg = "Your given number is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "error_username") {
    $msg = "The username is incorrect!";
    header("Location: index.php?msg=".$msg);
} else {
    $msg = "The username and password are incorrect!";
    header("Location: index.php?msg=".$msg);
}
?>
