<?php
session_start();
include("config/connection.php");

$query_get = mysqli_query($conn, "SELECT * from tbl_information_new where ID=".$_POST['InfoID']) or die(mysqli_error($conn));
$result_get=mysqli_fetch_array($query_get);

if($_FILES['Image1']['name'])
{
$filepath1=$result_get['Image1'];
unlink($filepath1);
$imageName1 =$_FILES['Image1']['name']; //rename image
$imageTmpName = $_FILES['Image1']['tmp_name'];
$fileType = $_FILES['Image1']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/images/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file1="documents/images/".$imageName1; 
}
else $target_file1=$result_get['Image1'];
}
else 
{
	$target_file1=$result_get['Image1'];
}



if($_FILES['Image2']['name'])
{
$filepath2=$result_get['Image2'];
unlink($filepath2);
$imageName1 =$_FILES['Image2']['name']; //rename image
$imageTmpName = $_FILES['Image2']['tmp_name'];
$fileType = $_FILES['Image2']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/images/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file2="documents/images/".$imageName1; 
}
else $target_file2=$result_get['Image2'];
}
else 
{
	$target_file2=$result_get['Image2'];
}



if($_FILES['Image3']['name'])
{
$filepath3=$result_get['Image3'];
unlink($filepath3);
$imageName1 =$_FILES['Image3']['name']; //rename image
$imageTmpName = $_FILES['Image3']['tmp_name'];
$fileType = $_FILES['Image3']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/images/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file3="documents/images/".$imageName1; 
}
else $target_file3=$result_get['Image3'];
}
else 
{
	$target_file3=$result_get['Image3'];
}



if($_FILES['Image4']['name'])
{
$filepath4=$result_get['Image4'];
unlink($filepath4);
$imageName1 =$_FILES['Image4']['name']; //rename image
$imageTmpName = $_FILES['Image4']['tmp_name'];
$fileType = $_FILES['Image4']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/images/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file4="documents/images/".$imageName1; 
}
else $target_file4=$result_get['Image4'];
}
else 
{
	$target_file4=$result_get['Image4'];
}



if($_FILES['Image5']['name'])
{
$filepath5=$result_get['Image5'];
unlink($filepath5);
$imageName1 =$_FILES['Image5']['name']; //rename image
$imageTmpName = $_FILES['Image5']['tmp_name'];
$fileType = $_FILES['Image5']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/images/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file5="documents/images/".$imageName1; 
}
else $target_file5=$result_get['Image5'];
}
else 
{
	$target_file5=$result_get['Image5'];
}

// BOQ image update
if($_FILES['BOQOfHollowBlock']['name']) {
    $boqFilePath = $result_get['BOQOfHollowBlock'];
    unlink($boqFilePath);
    $boqImageName = $_FILES['BOQOfHollowBlock']['name'];
    $boqImageTmpName = $_FILES['BOQOfHollowBlock']['tmp_name'];
    $boqFileExt = explode('.', $boqImageName);
    $boqFileActualExt = strtolower(end($boqFileExt));
	$allowed = array('doc','docx','pdf','jpg','jpeg','png','csv','xsl','xlsx');

    if (in_array($boqFileActualExt, $allowed)) {
        $directory = 'documents/boq/';
        $result = move_uploaded_file($boqImageTmpName, $directory.$boqImageName);
        $target_boq_file = "documents/boq/".$boqImageName;
    } else {
        $target_boq_file = $result_get['BOQOfHollowBlock'];
    }
} else {
    $target_boq_file = $result_get['BOQOfHollowBlock'];
}


$query="UPDATE tbl_information_new SET
		FinancialYear='".$_POST['FinancialYear']."',
		NameOfTender='".$_POST['NameOfTender']."',
		TenderAmount='".$_POST['TenderAmount']."',
		BOQOfHollowBlock='".$target_boq_file."',
		WorkDone='".$_POST['WorkDone']."',
		QuntOf10Inch='".$_POST['QuntOf10Inch']."',
		QuntOf10InchBlock='".$_POST['QuntOf10InchBlock']."',
		OuntOf10Inchfired='".$_POST['OuntOf10Inchfired']."',
		ProOf10InchBlock='".$_POST['ProOf10InchBlock']."',
		ReaOf10InchFired='".$_POST['ReaOf10InchFired']."',
		QuntOf5Inch='".$_POST['QuntOf5Inch']."',
		QuntOf5InchBlock='".$_POST['QuntOf5InchBlock']."',
		OuntOf5Inchfired='".$_POST['OuntOf5Inchfired']."',
		ProOf5InchBlock='".$_POST['ProOf5InchBlock']."',
		ReaOf5InchFired='".$_POST['ReaOf5InchFired']."',
		QuntOfHering='".$_POST['QuntOfHering']."',
		QuntOfHeringBlock='".$_POST['QuntOfHeringBlock']."',
		OuntOfHeringfired='".$_POST['OuntOfHeringfired']."',
		ProOfHeringBlock='".$_POST['ProOfHeringBlock']."',
		ReaOfHeringFired='".$_POST['ReaOfHeringFired']."',
		Image1Caption='".$_POST['Image1Caption']."',
		Image2Caption='".$_POST['Image2Caption']."',
		Image3Caption='".$_POST['Image3Caption']."',
		Image4Caption='".$_POST['Image4Caption']."',
		Image5Caption='".$_POST['Image5Caption']."',
		Image1='".$target_file1."',
		Image2='".$target_file2."',
		Image3='".$target_file3."',
		Image4='".$target_file4."',
		Image5='".$target_file5."'
		WHERE ID=".$_POST['InfoID'];
		
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

/*
$query="UPDATE tbl_court SET
		OfficeID=".$_SESSION['OfficeID'].",
		UpazilaID=".$_POST['UpazilaID'].",
		LandSize='".$_POST['LandSize']."',
		OwenershipInfo='".$_POST['OwenershipInfo']."',
		OwenershipInfoFile='".$image1."',
		DagKhatiyan='".$_POST['DagKhatiyan']."',
		DagKhatiyanFile='".$image2."',
		LandTaxInfo='".$_POST['LandTaxInfo']."',
		LandTaxInfoFile='".$file3."',
		BuildingLocation='".$_POST['BuildingLocation']."',
		OtherInstallationInfo='".$_POST['OtherInstallationInfo']."',
		SurveyReport='".$_POST['SurveyReport']."',
		SurveyReportFile='".$file4."',
		OtherOfficeNames='".$_POST['OtherOfficeNames']."',
		OtherOfficeDemand='".$_POST['OtherOfficeDemand']."',
		OtherOfficeDemandFile='".$file5."',
		BuildingPhotoFile='".$file6."',
		EstablishYear='".$_POST['EstablishYear']."',
		PlinthArea='".$_POST['PlinthArea']."',
		FloorArea='".$_POST['FloorArea']."',
		UnoComment='".$_POST['UnoComment']."',
		UnoCommentFile='".$file7."',
		EmptySpace='".$_POST['EmptySpace']."',
		EmptySpaceFile='".$file8."',
		DistrictJudgeComment='".$_POST['DistrictJudgeComment']."',
		DistrictJudgeCommentFile='".$file9."',
		InsertDate='".date('Y-m-d')."',
		OrderID=".$lastID;

        $query_update = "UPDATE tbl_code
                 SET 
                        `CodeNo` = '{$code_no}',
                        `CodeName` = '{$code_name}',
                        `CodeNoBN` = '{$code_no_bn}',
                        `CodeNameBN` = '{$code_name_bn}',
                        `head_office` = '{$head_office}',
                        `zone_office` = '{$zone_office}',
                        `circle_office` = '{$circle_office}',
                        `division_office` = '{$division_office}',
                        `training_academy` = '{$training_academy}'
                        
                        WHERE ID = $msg " ;

        $update_code = mysqli_query($conn, $query_update);

        //echo $query_update; */

if($result)
{
	header("Location: home.php?msg=Information Updated Successfully");
}

  

?>