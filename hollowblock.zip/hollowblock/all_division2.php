<?php 
session_start();

if ($_SESSION['flag']=='ok') {
include("config/connection.php");

?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database of Tree Information</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <!--<div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>-->
        </div>

        <!-- content-start -->
<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Divisional Reports</strong>
                                <a href="dashboard_by_all_division_excel2.php" style="float:right; text-decoration:underline; font-weight:bold;" target="_blank">All Division Export to Excel</a>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Office</th>
                                            <th>No of Information</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php
					$total=0; 
                    $sl = 0;
					$qur="SELECT  tbl_information_new.OfficeID, Count(tbl_information_new.ID) as noofinformation, ".DBHR.".hrtoffice.OfficeName 
					from  tbl_information_new 
					INNER JOIN ".DBHR.".hrtoffice on tbl_information_new.OfficeID=".DBHR.".hrtoffice.OfficeID
					GROUP BY  tbl_information_new.OfficeID";
                    $query1 = mysqli_query($conn,$qur) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
						$total=$total+$result1['noofinformation'];
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['OfficeName']?></td>
<td><?=$result1['noofinformation']?></td>
<td><a href="dashboard_by_division2.php?officeid=<?php echo $result1['OfficeID'];?>" style="color:green; font-size:12px; text-align:center; font-weight:bold;">View Details</a><br>

<a href="dashboard_by_division_excel2.php?officeid=<?php echo $result1['OfficeID'];?>" style="color:green; font-size:12px; text-align:center; font-weight:bold;" target="_blank">Export to Excel</a>
</td></tr>
                                    <?php }?>
                                    
                                    <tr><td>&nbsp;</td><td>&nbsp;</td><td>  <?php echo $total; ?>   </td> <td>&nbsp;</td></tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
