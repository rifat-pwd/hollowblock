<?php
session_start();
include("config/connection.php");

    $query1 = mysqli_query($conn, "SELECT ID FROM tbl_tree ORDER BY OrderID DESC LIMIT 1");
    $result1 = mysqli_fetch_array($query1);
    $lastID1=$result1['ID']+1;
	
	/*
	$target_dir = "documents/tree/";
	$target_file1 = $target_dir . basename($_FILES["Image1"]["name"]);
	$target_file2 = $target_dir . basename($_FILES["Image2"]["name"]);
	$target_file3 = $target_dir . basename($_FILES["Image3"]["name"]);
	$target_file4 = $target_dir . basename($_FILES["Image4"]["name"]);
	$target_file5 = $target_dir . basename($_FILES["Image5"]["name"]);
	
	
	$imageName1 = $_FILES['Image1']['name'];
	$imageName2 = $_FILES['Image2']['name'];
	$imageName3 = $_FILES['Image3']['name'];
	$imageName4 = $_FILES['Image4']['name'];
	$imageName5 = $_FILES['Image5']['name'];
			
			
	$imageTmpName1 = $_FILES['Image1']['tmp_name'];
	$imageTmpName2 = $_FILES['Image2']['tmp_name'];
	$imageTmpName3 = $_FILES['Image3']['tmp_name'];
	$imageTmpName4 = $_FILES['Image4']['tmp_name'];
	$imageTmpName5 = $_FILES['Image5']['tmp_name'];
	
	$fileSize1 = $_FILES['Image1']['size'];
	$fileSize2 = $_FILES['Image2']['size'];
	$fileSize3 = $_FILES['Image3']['size'];
	$fileSize4 = $_FILES['Image4']['size'];
	$fileSize5 = $_FILES['Image5']['size'];
	
	$fileType1 = $_FILES['Image1']['type'];
	$fileType2 = $_FILES['Image2']['type'];
	$fileType3 = $_FILES['Image3']['type'];
	$fileType4 = $_FILES['Image4']['type'];
	$fileType5 = $_FILES['Image5']['type'];
			
	$fileExt1 = explode('.', $imageName1);
	$fileExt2 = explode('.', $imageName2);
	$fileExt3 = explode('.', $imageName3);
	$fileExt4 = explode('.', $imageName4);
	$fileExt5 = explode('.', $imageName5);

	$fileActualExt1 = strtolower(end($fileExt1));
	$fileActualExt2 = strtolower(end($fileExt2));
	$fileActualExt3 = strtolower(end($fileExt3));
	$fileActualExt4 = strtolower(end($fileExt4));
	$fileActualExt5 = strtolower(end($fileExt5));

    $allowed = array('doc','docx','pdf','jpg','jpeg','png');
			
	if(($target_file1 != "documents/tree/") && in_array($fileActualExt1, $allowed)){
		move_uploaded_file($_FILES["Image1"]["tmp_name"], $target_file1);
	}else{
		$target_file1 = null;
	}
	if(($target_file2 != "documents/tree/") && in_array($fileActualExt2, $allowed)){
		move_uploaded_file($_FILES["Image2"]["tmp_name"], $target_file2);
	}else{
		$target_file2 = null;
	}
	if(($target_file3 != "documents/tree/") && in_array($fileActualExt3, $allowed)){
		move_uploaded_file($_FILES["Image3"]["tmp_name"], $target_file3);
	}else{
		$target_file3 = null;
	}
	if(($target_file4 != "documents/tree/") && in_array($fileActualExt4, $allowed)){
		move_uploaded_file($_FILES["Image4"]["tmp_name"], $target_file4);
	}else{
		$target_file4 = null;
	}
	if(($target_file5 != "documents/tree/") && in_array($fileActualExt5, $allowed)){
		move_uploaded_file($_FILES["Image5"]["tmp_name"], $target_file5);
	}else{
		$target_file5 = null;
	}
		*/

    $query = "INSERT INTO tbl_tree SET
		OfficeID=".$_SESSION["OfficeID"].",
		PlaceName='".$_POST['PlaceName']."',
		TreeType='".$_POST['TreeType']."',
		TreeVariant='".$_POST['TreeVariant']."',
		TreeNo='".$_POST['TreeNo']."',
		PitchPrepare='".$_POST['PitchPrepare']."',
		SeedCollect='".$_POST['SeedCollect']."',
		SeedPlant='".$_POST['SeedPlant']."',
		PlantedNo='".$_POST['PlantedNo']."',
		Comments='".$_POST['Comments']."',
		InsertDate='".date('Y-m-d')."',
		OrderID=".$lastID1;

$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
		
if($result)
{
	header("Location: view_tree.php?msg=Information Added Successfully");
}


/*
Image1='".$target_file1."',
		Image2='".$target_file2."',
		Image3='".$target_file3."',
		Image4='".$target_file4."',
		Image5='".$target_file5."',
		Image1Caption='".$_POST['Image1Caption']."',
		Image2Caption='".$_POST['Image2Caption']."',
		Image3Caption='".$_POST['Image3Caption']."',
		Image4Caption='".$_POST['Image4Caption']."',
		Image5Caption='".$_POST['Image5Caption']."',
*/		

?>