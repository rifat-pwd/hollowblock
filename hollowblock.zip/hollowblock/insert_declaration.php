<?php
session_start();
include("config/connection.php");
/*insert into contract*/

$query=mysqli_query($conn, "SELECT ID from tbl_information ORDER BY ID DESC LIMIT 1");
$result=mysqli_fetch_array($query);
$lastID=$result['ID']+1;


$query="INSERT INTO tbl_information SET
		OfficeID=".$_SESSION['OfficeID'].",
		Circular=".$_POST['Circular'].",
		NoOfTender='".$_POST['NoOfTender']."',
		IsHollowBlock='".$_POST['IsHollowBlock']."',
		NoOfHollowBlockTender='".$_POST['NoOfHollowBlockTender']."',
		Remarks='".$_POST['Remarks']."',
		InsertDate='".date('Y-m-d')."',
		OrderID=".$lastID;
$result = mysqli_query($conn, $query); 

		
if($result)
{
	header("Location: add_declaration.php?msg=Information Added Successfully");
}
?>