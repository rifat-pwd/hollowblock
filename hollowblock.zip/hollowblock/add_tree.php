<?php 
session_start();

if ($_SESSION['flag'] == 'ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Add Pond</title>
    <meta name="description" content="View Data">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <?php include 'css_master.php';?>

<style>
	body .main-body {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}

body .main-body .col-md-3 {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}

        .space {
            width:100%; 
            height:15px;
        }
        .col-md-3 {
            font-size:12px !important;
        }
</style>

</head>

<body>
    <?php include 'sidebar.php';?>
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <?php include 'navbar.php';?>
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
</div>
            
            <div class="col-md-12 main-body">
                <div class="card">
                    <div class="card-header">
                        <strong>Add New Information</strong> 
                    </div>
                    
                    <div class="card-body card-block">
                    <form action="insert_tree.php" method="post" enctype="multipart/form-data" class="form-horizontal">
                    
                    <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

            <?php }
		?>

                    <div class="row form-group">

<div class="col-md-3"><label for="text-input" class=" form-control-label">রোপনের স্থান:<span style="color: red">*</span></label></div>
<div class="col-md-4">  
<input type="text" id="PlaceName" name="PlaceName" placeholder="" class="form-control align-left" required ></textarea>
<small class="form-text text-muted"></small></div> 
</div>

<div class="space"></div>
                           
 <div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">গাছের ধরণ:<span style="color: red">*</span></label></div>                             
 
<div class="col-md-3">
<select name="TreeType" class="form-control">
                            <option value="">নির্বাচন করুন</option>
                            <option value="বৃক্ষ"> বৃক্ষ </option>
                            <option value="গুল্ম"> গুল্ম </option>
                            <option value="বিরুৎ"> বিরুৎ </option>
                            </select>
</div>

<div class="col-md-3">
<select name="TreeVariant" class="form-control">
                            <option value="">নির্বাচন করুন</option>
                            <option value="আম"> আম </option>
                            <option value="জাম"> জাম </option>
                            <option value="লিচু"> লিচু </option>
                            <option value="পলাশ"> পলাশ </option>
                            <option value="বাগান বিলাস"> বাগান বিলাস </option>
                            </select>
</div>

</div>

<div class="space"></div>

<div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">সংখ্যা:<span style="color: red">*</span></label></div>

<div class="col-md-3">
<select name="TreeNo" class="form-control">
                            <option value="">নির্বাচন করুন</option>
                            <option value="৬০"> ৬০ </option>
                            <option value="৫০"> ৫০ </option>
                            <option value="১৫"> ১৫ </option>
                            <option value="১০"> ১০ </option>
                            </select>
</div>
</div>

<div class="space"></div>

<div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">পিচ তৈরী:<span style="color: red">*</span></label></div>
<div class="col-md-3">  
<input type="date" id="PitchPrepare" name="PitchPrepare" placeholder="DD-MM-YYYY" class="form-control align-left"></textarea>
<small class="form-text text-muted"></small></div>
</div>

<div class="space"></div>

<div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">চারা সংগ্রহ:<span style="color: red">*</span></label></div>
<div class="col-md-3">  
<input type="date" id="SeedCollect" name="SeedCollect" placeholder="DD-MM-YYYY" class="form-control align-left"></textarea>
<small class="form-text text-muted"></small></div>                          
</div>

<div class="space"></div>

<div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">চারা রোপন:<span style="color: red">*</span></label></div>
<div class="col-md-3">  
<input type="date" id="SeedPlant" name="SeedPlant" placeholder="DD-MM-YYYY" class="form-control align-left"></textarea>
<small class="form-text text-muted"></small></div> 
 </div>
 
 <div class="space"></div>

<div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">৩০ সেপ্টেম্বর /৩০ ডিসেম্বর/৩০ মার্চে রোপিত গাছের সংখ্যা<span style="color: red">*</span></label></div>
<div class="col-md-3">  
<input type="text" id="PlantedNo" name="PlantedNo" placeholder="" class="form-control align-left"></textarea>
<small class="form-text text-muted"></small></div> 
 </div>

 <div class="space"></div>

<div class="row form-group">
<div class="col-md-3"><label for="text-input" class=" form-control-label">মন্তব্য:<span style="color: red">*</span></label></div>
<div class="col-md-6"> 
<textarea type="text" id="Comments" name="Comments" placeholder="" class="form-control align-left"></textarea>
<small class="form-text text-muted"></small></div> 
 </div>  

<!--
<div class="space"></div>
                             
<div class="row form-group">                             
<div class="col-md-2"><label class="form-label">ছবি নির্বাচন করুন: </div>
 <div class="col-md-4">ছবি আপলোড করুন: <span style="color: red">*</span></label> <input type="file" id="Image1" class="form-control rounded-0 border-info formFileMultiple" name="Image1" required></div>
 <div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image1Caption" name="Image1Caption" placeholder="" class="form-control" required ></div>
 </div>
 <div class="space"></div>
 <div class="row form-group">                             
<div class="col-md-2"><label class="form-label">&nbsp;</label></div>
<div class="col-md-4">ছবি আপলোড করুন: <span style="color: red">*</span></label> <input type="file" id="Image2" class="form-control rounded-0 border-info formFileMultiple" name="Image2" required></div>
 <div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image2Caption" name="Image2Caption" placeholder="" class="form-control" required ></div>
 </div>
 <div class="space"></div>
 
 
 <div class="row form-group">                             
<div class="col-md-2"><label class="form-label">&nbsp; </label></div>
<div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image3" class="form-control rounded-0 border-info formFileMultiple" name="Image3" ></div>
 <div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image3Caption" name="Image3Caption" placeholder="" class="form-control"  ></div>
 </div>
 <div class="space"></div>
 
 <div class="row form-group">
 <div class="col-md-2">&nbsp; </div>
 <div class="col-md-4">ছবি আপলোড করুন:<input type="file" id="Image4" class="form-control rounded-0 border-info formFileMultiple" name="Image4" ></div>
 <div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image4Caption" name="Image4Caption" placeholder="" class="form-control"  ></div>
 </div>
 <div class="space"></div>
 
 <div class="col-md-2"></div><div class="col-md-4">ছবি আপলোড করুন:<input type="file" id="Image5" class="form-control rounded-0 border-info formFileMultiple" name="Image5" ></div>
 <div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image5Caption" name="Image5Caption" placeholder="" class="form-control"  ></div>
 <div class="space"></div>

 -->

                 </div>
                 <div class="card-footer">
                     <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                         <i class="fa fa-dot-circle-o"></i> Submit
                     </button>
                     <!-- <button type="reset" class="btn btn-danger btn-sm">
                         <i class="fa fa-ban"></i> Reset
                     </button> -->
                 </div>
                 </form>
             
 
     <!-- Right Panel -->

<?php include 'js_master.php';?>

</body>
</html>

<?php

} elseif ($_SESSION["flag"] == "error_pass") {
    $msg = "The password is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "captcha") {
    $msg = "Your given number is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "error_username") {
    $msg = "The username is incorrect!";
    header("Location: index.php?msg=".$msg);
} else {
    $msg = "The username and password are incorrect!";
    header("Location: index.php?msg=".$msg);
}
?>