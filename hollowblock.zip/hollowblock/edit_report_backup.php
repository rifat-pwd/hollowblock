<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Uses of Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>
    <style>
	.space {
	width:100%; 
	height:15px;
	}
	.col-md-3 {
		font-size:12px !important;
	}
	/*.background {
		border:1px solid #ccc; padding:5px;
		background-color:#F8F8FA;
	} */
	.innara {
		font-size:14px;
		color:#000000;
		text-decoration:underline;
	}
	
	</style>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
                


        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="update.php" method="post" enctype="multipart/form-data" class="form-horizontal">
					<input type="hidden" name="CourtID" value="<?php echo $_GET['id'];?>">
					
                        <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php }
		$query = mysqli_query($conn, "SELECT * from tbl_court where ID=".$_GET['id']) or die(mysqli_error($conn));
       $result1=mysqli_fetch_array($query);
		
		?>
                        
                        
                       <div class="row form-group">
                       
                        <div class="col-md-3"><label for="text-input" class=" form-control-label">১. উপজেলা নির্বাচন করুন:<span style="color: red">*</span></label></label></div>
                            <div class="col-md-4"><select id="UpazilaID" name="UpazilaID" style="width:360px; height:40px;" required>
                            <?php
							$result = mysqli_query($conn, "SELECT * from tbl_upazila where UserID='".$_SESSION["UserID"]."'")or die(mysqli_error($conn));
	    					while($row=mysqli_fetch_array($result)) {
							?>
                            <option value="<?php echo $row['ID']?>" <?php if($row['ID']==$result1['UpazilaID']) echo "selected"; ?>><?php echo $row['UpazilaName'];?></option>
                            <?php } ?>
                            </select></div> 
                            
                           <div class="space"></div>
                           
                           <div class="col-md-3"><label for="text-input" class=" form-control-label">২. কোর্ট ভবনের জমির পরিমান:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="LandSize" name="LandSize" placeholder="" class="form-control"  
                            value="<?php echo $result1['LandSize'];?>"><small class="form-text text-muted"></small></div> 
                            
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class="form-control-label">৩. জমির মালিকানার তথ্য:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="OwenershipInfo" name="OwenershipInfo" placeholder="" class="form-control" value="<?php echo $result1['OwenershipInfo'];?>"><small class="form-text text-muted"></small></div> 
                            <div class="col-md-4"><input type="file" id="OwenershipInfoFile" name="OwenershipInfoFile" placeholder="" class="form-control"><small class="form-text text-muted"></small><?php if($result1['OwenershipInfoFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['OwenershipInfoFile'];?>" target="_blank">Download File</a> <?php };?></div>
                            
                            
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৪. জমির দাগ এবং খতিয়ান নং:</label></div>
                            <div class="col-md-4"><input type="text" id="DagKhatiyan" name="DagKhatiyan" placeholder="" class="form-control" value="<?php echo $result1['DagKhatiyan'];?>"><small class="form-text text-muted"></small></div> 
                             <div class="col-md-4"><input type="file" id="DagKhatiyanFile" name="DagKhatiyanFile" placeholder="" class="form-control"><small class="form-text text-muted"></small><?php if($result1['DagKhatiyanFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['DagKhatiyanFile'];?>" target="_blank">Download File</a> <?php };?></div>
                                                        
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৫. জমির কর প্রদানের তথ্য এবং কর প্রদানের রশিদ (যদি থাকে):</label></div>
                            <div class="col-md-4"><input type="text" id="LandTaxInfo" name="LandTaxInfo" placeholder="" class="form-control" value="<?php echo $result1['LandTaxInfo'];?>"><small class="form-text text-muted"></small></div> 
                            <div class="col-md-4"><input type="file" id="LandTaxInfoFile" name="LandTaxInfoFile" placeholder="" class="form-control"><small class="form-text text-muted"></small><?php if($result1['LandTaxInfoFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['LandTaxInfoFile'];?>" target="_blank">Download File</a> <?php };?></div>
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৬. কোর্ট ভবনটি উপজেলা পরিষদ ক্যাম্পাসের বাহিরে কিনা?<span style="color: red">*</span></label></div>
                            <div class="col-md-4" style="font-size:14px;">
                            <input type="radio" id="yesbtn" name="BuildingLocation" placeholder="" value="Yes" <?php if($result1['BuildingLocation']=='Yes') echo 'checked'; ?>>  হ্যা &nbsp;&nbsp;&nbsp;
                            <input type="radio" id="nobtn" name="BuildingLocation" placeholder="" value="No"  <?php if($result1['BuildingLocation']=='No') echo 'checked'; ?>>না</div> 
                            
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৭. উক্ত জমিতে বর্তমানে কোর্ট ভবন ছাড়া অন্য স্থাপনার বিবরন:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="OtherInstallationInfo" name="OtherInstallationInfo" placeholder="" class="form-control" value="<?php echo $result1['OtherInstallationInfo'];?>"><small class="form-text text-muted"></small></div> 

                            
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৮. <span id="test1">উপজেলা পরিষদ ক্যাম্পাসের ডিজিটাল সার্ভে রিপোর্ট:</span><span style="color: red">*</span></label></div>
                             <div class="col-md-4"><input type="text" id="SurveyReport" name="SurveyReport" placeholder="" class="form-control" value="<?php echo $result1['SurveyReport'];?>"><small class="form-text text-muted"></small></div>
                            <div class="col-md-4"><input type="file" id="SurveyReportFile" name="SurveyReportFile" placeholder="<?php echo $result1['SurveyReportFile'];?>" class="form-control"><?php if($result1['SurveyReportFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['SurveyReportFile'];?>" target="_blank">Download File</a> <?php };?></div>
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৯. বর্তমানে কোর্ট ভবন ব্যবহারকারী অফিসসমূহের নাম:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="OtherOfficeNames" name="OtherOfficeNames" placeholder="" class="form-control" value="<?php echo $result1['OtherOfficeNames'];?>"><small class="form-text text-muted"></small></div>
                            
                            
                            
                         <div class="space"></div>
                            <div class="background">
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১০. উক্ত ভবন অপসারন করে সমন্বিত অফিস ভবন করা হলে উপজেলা পর্যায়ে যে সব অফিসের চাহিদা আছে তার নামের তালিকা এবং কর্মকর্তা কর্মচারির সংখ্যা:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><textarea type="text" id="OtherOfficeDemand" name="OtherOfficeDemand" placeholder="" class="form-control"><?php echo $result1['OtherOfficeDemand'];?></textarea></div>
                            <div class="col-md-4"><input type="file" id="OtherOfficeDemandFile" name="OtherOfficeDemandFile" placeholder="" class="form-control"><small class="form-text text-muted"></small><?php if($result1['OtherOfficeDemandFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['OtherOfficeDemandFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            
                            </div>
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১১. ভবনের ছবি:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="file" id="BuildingPhotoFile" name="BuildingPhotoFile" placeholder="" class="form-control"><small class="form-text text-muted"></small></div>
                           <div class="col-md-4"><?php if($result1['BuildingPhotoFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['BuildingPhotoFile'];?>" target="_blank">Download Image</a><?php };?></div>
                            
                            <!--<div class="col-md-4"><input type="file" id="code_no_bn" name="file" placeholder="" class="form-control" required><small class="form-text text-muted"></small></div>-->
                            
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১১. ভবনের নির্মান সাল:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="EstablishYear" name="EstablishYear" placeholder="" class="form-control" value="<?php echo $result1['EstablishYear'];?>"><small class="form-text text-muted"></small></div>

                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১২. ভবনের প্লিন্থ এরিয়া:<span style="color: red">*</span></label></div>
                             <div class="col-md-4"><input type="text" id="PlinthArea" name="PlinthArea" placeholder="" class="form-control" value="<?php echo $result1['PlinthArea'];?>"><small class="form-text text-muted"></small></div>
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১৩. ভবনের মোট ফ্লোর এরিয়া:<span style="color: red">*</span></label></div>
                             <div class="col-md-4"><input type="text" id="FloorArea" name="FloorArea" placeholder="" class="form-control" value="<?php echo $result1['FloorArea'];?>"><small class="form-text text-muted"></small></div>

                            
                            
                            
                           <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১৪. উপজেলা নির্বাহী কর্মকর্তার মতামত :</label></div>
                            <div class="col-md-4"><input type="text" id="UnoComment" name="UnoComment" placeholder="" class="form-control" value="<?php echo $result1['UnoComment'];?>"><small class="form-text text-muted"></small></div>
                            <div class="col-md-4"><input type="file" id="UnoCommentFile" name="UnoCommentFile" placeholder="" class="form-control"><small class="form-text text-muted"></small><?php if($result1['UnoCommentFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['UnoCommentFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১৫. কোর্ট বিল্ডিং অপসারন করা না গেলে উপজেলা পরিষদ অঙ্গনে পর্যাপ্ত জায়গা আছে কিনা? থাকলে জমির পরিমান<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="EmptySpace" name="EmptySpace" placeholder="" class="form-control" value="<?php echo $result1['EmptySpace'];?>"><small class="form-text text-muted"></small></div>
                            <div class="col-md-4"><input type="file" id="EmptySpaceFile" name="EmptySpaceFile" placeholder="" class="form-control"><small class="form-text text-muted"></small><?php if($result1['EmptySpaceFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['EmptySpaceFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            
                            
                            
                            
                            
                             <!--<div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">জেলা জজ মহোদয়ের মন্তব্য:</label></div>
                            <div class="col-md-4"><input type="text" id="DistrictJudgeComment" name="DistrictJudgeComment" placeholder="" class="form-control" value="<?php echo $result1['DistrictJudgeComment'];?>"><small class="form-text text-muted"></small></div>
                            
                            <div class="col-md-4"><?php if($result1['DistrictJudgeCommentFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['DistrictJudgeCommentFile'];?>" target="_blank">Download File</a> <?php };?></div> -->
                            

                   </div> 
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Update Now
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <?php include 'js_master.php';?>
        <script src="jquery.min.js"></script>
        <script>
$(document).ready(function(){
  $("#nobtn").click(function(){
    $("#test1").text("উপজেলা পরিষদ ক্যাম্পাসের ডিজিটাল সার্ভে রিপোর্ট:");
  });
  $("#yesbtn").click(function(){
    $("#test1").text("কোর্ট বিল্ডিংয়ের পারিপার্শ্বিক ভবন ও রাস্তাসহ ডিজিটাল সার্ভে রিপোর্ট");
  });
});
</script>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
