<?php
session_start();
include("config/connection.php");

if(isset($_GET['id'])) {
    $id = $_GET['id'];

$query = mysqli_query($conn, "SELECT * FROM tbl_pond WHERE ID=$id");
    $row = mysqli_fetch_array($query);

    for ($imgNum = 1; $imgNum <= 5; $imgNum++) {
        $imageFilePath = 'documents/pond/' . $row['Image'.$imgNum];
        if (!empty($row['Image'.$imgNum]) && file_exists($imageFilePath)) {
            try {
                if (!unlink($imageFilePath)) {
                    throw new Exception('Failed to delete ' . $imageFilePath);
                }
            } catch (Exception $e) {
                echo 'Error: ' . $e->getMessage();
            }
        }
    }

    $delete = mysqli_query($conn, "DELETE FROM tbl_pond WHERE ID=$id");

    if($delete) {
        header("Location: view_pond.php?msg=Deleted Successfully");
        exit(); 
    }
}
?>