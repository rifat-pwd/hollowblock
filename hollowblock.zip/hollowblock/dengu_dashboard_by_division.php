<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (ERP) for Co-ordination</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>
        
        <?php 
		$result = mysqli_query($conn, "SELECT ".DBHR.".hrtoffice.OfficeName FROM ".DBHR.".hrtoffice 
								WHERE ".DBHR.".hrtoffice.OfficeID=".$_GET['officeid'])or die(mysqli_error($conn));
	    $row=mysqli_fetch_array($result);
	   ?>

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $row['OfficeName'];?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
            
         <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">01. All the ponds / reservoirs / lakes / canals under the Public Works Department have been cleared and cleaned</strong> 
                            </div>
                       <div class="card-body">
                      <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 1 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">02. Necessary steps have been taken to remove waste from all installations under the Public Works Department.</strong>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 2 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
                <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">03. Measures have been taken to keep the drains and adjoining areas of all government hospitals clean and tidy under the Public Works Department.</strong> 
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 3 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">04. All office, courts and courtyards are kept free of bushes and weeds, adjacent roads and drains are also being cleaned regularly.</strong>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 4 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div> 
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">05. All sources of stagnant water are being removed as much as possible and regular spraying of disinfectants, floating larvae are being destroyed.</strong>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 5 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">06. Regular Measures have been taken to spray mosquito larvae destroying disinfectants in the water stored in the building for casting.</strong> 
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 6 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title" style="color:green;">07. Unnecessary stagnant water has been removed at construction sites under all Public Works Departments.</strong>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">    
					<?php 
                    
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 7 AND OfficeID=".$_GET['officeid']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                       
                        ?>
<tr><td colspan="2"><b><?=$result1['AssetName']?><span style="float:right;"> Completion Date: &nbsp; <?php echo date('d-m-Y',strtotime($result1['CompletionDate']));?></span></b></td></tr>
<tr><td><img src="images/dengu/<?=$result1['Image1']?>" width="400"></td><td><img src="images/dengu/<?=$result1['Image2']?>" width="400"></td></tr>

                                    <?php }?>
                                        
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    

    <!-- Right Panel -->


    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
