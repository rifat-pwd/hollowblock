<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Edit Tree</title>
    <meta name="description" content="Edit Data">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <?php include 'css_master.php';?>
    
<style>

	body .main-body {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}

body .main-body .col-md-3 {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}

        .space {
            width:100%; 
            height:15px;
        }
        .col-md-3 {
            font-size:12px !important;
        }

</style>

</head>

<body>
    <?php include 'sidebar.php';?>
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <?php include 'navbar.php';?>
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>


        <div class="col-md-12 main-body">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="update_tree.php" method="post" enctype="multipart/form-data" class="form-horizontal">


                <?php if(isset($_GET['msg_success'])){?>
                <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

            <?php }
                        $query = mysqli_query($conn, "SELECT * FROM tbl_tree WHERE ID=".$_GET['id']) or die(mysqli_error($conn));
                        $result1 = mysqli_fetch_array($query);
                        ?>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">রোপনের স্থান:<span style="color: red">*</span></label></div>
    <div class="col-md-4">
        <input type="hidden" name="ID" value="<?php echo $_GET['id']; ?>">  
        <input type="text" id="PlaceName" name="PlaceName" placeholder="" class="form-control align-left" value="<?php echo $result1['PlaceName']; ?>">
        <small class="form-text text-muted"></small>
    </div>
</div>

<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">গাছের ধরণ:<span style="color: red">*</span></label></div>
    <div class="col-md-3">
        <select name="TreeType" class="form-control" required>
            <option value="">নির্বাচন করুন</option>
            <option value="বৃক্ষ" <?php if($result1['TreeType'] == 'বৃক্ষ') echo 'selected'; ?>> বৃক্ষ </option>
            <option value="গুল্ম" <?php if($result1['TreeType'] == 'গুল্ম') echo 'selected'; ?>> গুল্ম </option>
            <option value="বিরুৎ" <?php if($result1['TreeType'] == 'বিরুৎ') echo 'selected'; ?>> বিরুৎ </option>
        </select>
    </div>
    <div class="col-md-3">
        <select name="TreeVariant" class="form-control" required>
            <option value="">নির্বাচন করুন</option>
            <option value="আম" <?php if($result1['TreeVariant'] == 'আম') echo 'selected'; ?>> আম </option>
            <option value="জাম" <?php if($result1['TreeVariant'] == 'জাম') echo 'selected'; ?>> জাম </option>
            <option value="লিচু" <?php if($result1['TreeVariant'] == 'লিচু') echo 'selected'; ?>> লিচু </option>
            <option value="পলাশ" <?php if($result1['TreeVariant'] == 'পলাশ') echo 'selected'; ?>> পলাশ </option>
            <option value="বাগান বিলাস" <?php if($result1['TreeVariant'] == 'বাগান বিলাস') echo 'selected'; ?>> বাগান বিলাস </option>
        </select>
    </div>
</div>

<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">সংখ্যা:<span style="color: red">*</span></label></div>
    <div class="col-md-3">
        <select name="TreeNo" class="form-control" required>
            <option value="">নির্বাচন করুন</option>
            <option value="৬০" <?php if($result1['TreeNo'] == '৬০') echo 'selected'; ?>> ৬০ </option>
            <option value="৫০" <?php if($result1['TreeNo'] == '৫০') echo 'selected'; ?>> ৫০ </option>
            <option value="১৫" <?php if($result1['TreeNo'] == '১৫') echo 'selected'; ?>> ১৫ </option>
            <option value="১০" <?php if($result1['TreeNo'] == '১০') echo 'selected'; ?>> ১০ </option>
        </select>
    </div>
</div>

<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">পিচ তৈরী:<span style="color: red">*</span></label></div>
    <div class="col-md-3">  
        <input type="date" id="PitchPrepare" name="PitchPrepare" placeholder="DD-MM-YYYY" class="form-control align-left" value="<?php echo $result1['PitchPrepare']; ?>">
        <small class="form-text text-muted"></small>
    </div>
</div>

<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">চারা সংগ্রহ:<span style="color: red">*</span></label></div>
    <div class="col-md-3">  
        <input type="date" id="SeedCollect" name="SeedCollect" placeholder="DD-MM-YYYY" class="form-control align-left" value="<?php echo $result1['SeedCollect']; ?>">
        <small class="form-text text-muted"></small>
    </div>                          
</div>

<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">চারা রোপন:<span style="color: red">*</span></label></div>
    <div class="col-md-3">  
        <input type="date" id="SeedPlant" name="SeedPlant" placeholder="DD-MM-YYYY" class="form-control align-left" value="<?php echo $result1['SeedPlant']; ?>">
        <small class="form-text text-muted"></small>
    </div> 
</div>                                           

<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">৩০ সেপ্টেম্বর /৩০ ডিসেম্বর/৩০ মার্চে রোপিত গাছের সংখ্যা:<span style="color: red">*</span></label></div>
    <div class="col-md-3">  
        <input type="text" id="PlantedNo" name="PlantedNo" placeholder="" class="form-control align-left" value="<?php echo $result1['PlantedNo']; ?>">
        <small class="form-text text-muted"></small>
    </div> 
</div>
 
<div class="space"></div>

<div class="row form-group">
    <div class="col-md-3"><label for="text-input" class="form-control-label">মন্তব্য:<span style="color: red">*</span></label></div>
    <div class="col-md-6">  
        <textarea id="Comments" name="Comments" placeholder="" class="form-control align-left"><?php echo $result1['Comments']; ?></textarea>
        <small class="form-text text-muted"></small>
    </div> 
</div>

<!--
<div class="space"></div>

<div class="space"></div>

<div class="col-md-2"><label class="form-label">ছবি নির্বাচন করুন: <span style="color: red">*</span></label></div>
<div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image1" class="form-control rounded-0 border-info formFileMultiple" name="Image1">
<small class="form-text text-muted"><a href="<?php echo $result1['Image1']; ?>" target="_blank">View Image 1</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image1Caption" name="Image1Caption" class="form-control" value="<?php echo $result1['Image1Caption']; ?>" ></div>
<div class="space"></div>


<div class="col-md-2"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image2" class="form-control rounded-0 border-info formFileMultiple" name="Image2">
<small class="form-text text-muted"><a href="<?php echo $result1['Image2']; ?>" target="_blank">View Image 2</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image2Caption" name="Image2Caption" class="form-control" value="<?php echo $result1['Image2Caption']; ?>" ></div>
<div class="space"></div>


<div class="col-md-2"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image3" class="form-control rounded-0 border-info formFileMultiple" name="Image3">
<small class="form-text text-muted"><a href="<?php echo $result1['Image3']; ?>" target="_blank">View Image 3</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image3Caption" name="Image3Caption" class="form-control" value="<?php echo $result1['Image3Caption']; ?>" ></div>
<div class="space"></div>


<div class="space"></div>


<div class="col-md-2"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image4" class="form-control rounded-0 border-info formFileMultiple" name="Image4">
<small class="form-text text-muted"><a href="<?php echo $result1['Image4']; ?>" target="_blank">View Image 4</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image4Caption" name="Image4Caption" class="form-control" value="<?php echo $result1['Image4Caption']; ?>" ></div>
<div class="space"></div>

<div class="col-md-2"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image5" class="form-control rounded-0 border-info formFileMultiple" name="Image5">
<small class="form-text text-muted"><a href="<?php echo $result1['Image5']; ?>" target="_blank">View Image 5</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image5Caption" name="Image5Caption" class="form-control" value="<?php echo $result1['Image5Caption']; ?>" ></div>
<div class="space"></div>               
-->

                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Update Now
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


<?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>