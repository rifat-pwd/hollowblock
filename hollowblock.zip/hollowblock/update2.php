<?php
session_start();
include("config/connection.php");

/*$query_update = mysqli_query($conn, "SELECT * from tbl_court where ID=".$_POST['CourtID']) or die(mysqli_error($conn));
$result_update=mysqli_fetch_array($query_update);
if($result_update['BuildingPhotoFile']==$_POST['BuildingPhotoFile'])
{
	echo "same";
}
else 
{
	echo "Other";
}
exit(); */

$query="UPDATE tbl_upazila SET
		UpazilaName='".$_POST['UpazilaName']."',
		UpazilaNameBn='".$_POST['UpazilaNameBn']."'
		WHERE ID=".$_POST['UpazilaID'];
		
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

if($result)
{
	header("Location: resources.php?msg=Information Updated Successfully");
}

  

?>