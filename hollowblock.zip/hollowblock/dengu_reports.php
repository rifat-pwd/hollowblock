<?php 
session_start();
if ($_SESSION['flag']=='ok') {
include("config/connection.php");
?>
<!doctype html>
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (Co-ordination)</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php //include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <!--<div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>-->
        </div>

        <!-- content-start -->
<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Divitional Reports</strong>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered" style="font-size:10px;">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>অফিসের নাম</th>
                                            <th colspan="2">গণপূর্ত অধিদপ্তরের আওতাধীন সকল পুকুর/জলাশয়/লেক/খাল কচুরীপানা মুক্ত ও পরিষ্কার পরিচ্ছন্ন করা হয়েছে।</th>
                                            <th colspan="2">গণপূর্ত অধিদপ্তরের আওতাধীন সকল স্থাপনার বর্জ অপসারণের বিষয়ে প্রয়োজনীয় ব্যবস্থা গ্রহণ করা হয়েছে।</th>
                                            <th colspan="2">গণপূর্ত অধিদপ্তরের আওতায় সকল সরকারি হাসপাতালের ড্রেইন এবং তৎসংলগ্ন এলাকা পরিষ্কার পরিচ্ছন্ন রাখার ব্যবস্থা গ্রহণ করা হয়েছে।</th>
                                            <th colspan="2">সকল অফিস আদালত ও বাসা বাড়ির আঙ্গিনার ঝোঁপ-ঝাড় ও আগাছা মুক্ত রাখা, সংলগ্ন রাস্তা, ড্রেইন নিয়মিত পরিষ্কার করা হচ্ছে।</th>
                                            <th colspan="2">জমানো পানির সকল উৎস যথাসম্ভব অপসারণ পূর্বক নিয়মিতভাবে জীবানু-নাশক ছিটানোর ব্যবস্থা ও পানিতে ভাসমান লার্ভা বিনষ্ট করা হচ্ছে। </th>
                                            <th colspan="2">ভবনের ঢালাইয়ের কিউরিং কাজে জমানো পানিতে মশার লার্ভা ধ্বংসকারী ওষধ নিয়মিতভাবে ছিটানোর ব্যবস্থা গ্রহণ করা হয়েছে।</th>
                                            <th colspan="2">সকল গণপূর্ত বিভাগের আওতাধীন নির্মাণ সাইটগুলোতে অপ্রয়োজনীয় আবদ্ধ পানি অপসারণ করা হয়েছে।</th>
                                        </tr>
                                        
                                        <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        <td>Yes/No</td>
                                        <td>Completion</td>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
					
					$user_id = array('1', '2','3', '4', '5','6', '7');
					
                    $sl = 0;
					$qur="SELECT tbl_workrecord.*, ".DBHR.".hrtoffice.OfficeName 
					from tbl_workrecord 
					INNER JOIN ".DBHR.".hrtoffice on tbl_workrecord.OfficeID=".DBHR.".hrtoffice.OfficeID
					GROUP BY tbl_workrecord.OfficeID";
                    $query1 = mysqli_query($conn,$qur) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['OfficeName']?></td>
<?php 
foreach ($user_id as $value) {
$qur1=mysqli_query($conn,"SELECT distinct tbl_workrecord.CompletionDate from tbl_workrecord WHERE AssetTypeID=".$value." AND OfficeID=".$result1['OfficeID']." order by CompletionDate ASC") or die(mysqli_error($conn));
$date='';
while($res1=mysqli_fetch_array($qur1)) {
	$date.=date('d-m-Y',strtotime($res1['CompletionDate']))."<br>";
	}
if($date!='') {
?>
<td>Yes</td>
<td><?php echo $date; ?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } } ?>


<?php /* 
$qur2=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=2 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res2=mysqli_fetch_array($qur2);
if($res2) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res2['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur3=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=3 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res3=mysqli_fetch_array($qur3);
if($res3) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res3['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur4=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=4 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res4=mysqli_fetch_array($qur4);
if($res4) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res4['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>

<?php 
$qur5=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=5 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res5=mysqli_fetch_array($qur5);
if($res5) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res5['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur6=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=6 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res6=mysqli_fetch_array($qur6);
if($res6) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res6['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur7=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=7 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res7=mysqli_fetch_array($qur7);
if($res7) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res7['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } */ ?>



</tr>

                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
