<?php
// Create connection
/* for online server */
$host = 'localhost';
$user = 'pwdshelltechnolo_shatabdi';
$pass = '[B$G,0zXp532';
$db = 'pwdshelltechnolo_pwdweb';

$conn = mysqli_connect($host, $user, $pass, $db);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if($_GET['intime']==-1)
{
	$intime='00:00:00';
}
else {
$time = strtotime('09:00');
$machineintime=$_GET['intime']-1980;
$intime = date("H:i:s", strtotime('+'.$machineintime.' minutes',$time));
}

if($_GET['outtime']==-1)
{
	$outtime='00:00:00';
}
else {
$outtimefixed = strtotime('17:00');
$machineouttime=$_GET['outtime']-2460;
$outtime = date("H:i:s", strtotime('+'.$machineouttime.' minutes',$outtimefixed));
}

$year= substr($_GET['date'], 0, 4);
$month= substr($_GET['date'], 4, 2);
$date= substr($_GET['date'], 6, 2);

$reportdate=$year.'-'.$month.'-'.$date;


/*echo "<br>Emp code=".$_GET['eid'];
echo "<br>Date=".$reportdate;
echo "<br>In Time=".$intime;
echo "<br>Out Time=".$outtime; */


	$queryInsert = "INSERT INTO basic (ID, ReportDate, OffIn, OffOut) VALUES ('".$_GET['eid']."', '".$reportdate."', '".$intime."', '".$outtime."')";
	$result= mysqli_query($conn,$queryInsert) or die(mysqli_error($conn));
?>