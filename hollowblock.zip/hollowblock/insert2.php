<?php
session_start();
include("config/connection.php");
/*insert into contract*/

/*$query=mysqli_query($conn, "SELECT ID from tbl_resouces ORDER BY OrderID DESC LIMIT 1");
$result=mysqli_fetch_array($query);
$lastID=$result['ID']+1;


$query="INSERT INTO tbl_resources SET
		OfficeID=".$_SESSION['OfficeID'].",
		ResourceName='".$_POST['ResourceName']."',
		Quantity='".$_POST['Quantity']."',
		OrderID=".$lastID;
$result = mysqli_query($conn, $query); */


$query="INSERT INTO tbl_upazila SET
		UpazilaName='".$_POST['UpazilaName']."',
		UpazilaNameBn='".$_POST['UpazilaNameBn']."',
		OfficeID=".$_SESSION['OfficeID'].",
		UserID=".$_SESSION["UserID"];
$result = mysqli_query($conn, $query);


if($result)
{
	header("Location:resources.php?msg=Information Add Successfully");
}
?>