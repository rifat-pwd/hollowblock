<?php 
session_start();
if ($_SESSION['flag']=='ok') {
include("config/connection.php");
header("Content-type: application/vnd.ms-excel; name='excel'");
header("Content-Disposition: attachment; filename=all_reports.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>
Reports Date:: <?php echo date('d-m-Y');?></strong>
                          
                                 <table style="font-size:12px; width:1200px; border:1px solid #000;" border="1">
                                    <thead>
                                        <tr>
                                            <th>ক্রমিক</th>
                                            <th>অফিসের নাম</th>
                                            <th>উপজেলার নাম</th>
                                            <th>কোর্ট ভবনের জমির পরিমান</th>
                                            <th>জমির মালিকানার তথ্য</th>
                                            <th>জমির দাগ এবং খতিয়ান নং</th>
                                            <th>জমির কর প্রদানের তথ্য এবং কর প্রদানের রশিদ(যদি থাকে)</th>
                                            <th>কোর্ট ভবনটি উপজেলা পরিষদ ক্যাম্পাসের বাহিরে কিনা?</th>
                                            <th>উক্ত জমিতে বর্তমানে কোর্ট ভবন ছাড়া অন্য স্থাপনার বিবরন</th>
                                            <th>উক্ত জায়গার ডিজিটাল সার্ভে রিপোর্ট</th>
                                            <th>বর্তমানে কোর্ট ভবন ব্যবহারকারী অফিসসমূহের নাম</th>
                                            <th>উক্ত ভবন অপসারন করে সমন্বিত অফিস ভবন করা হলে উপজেলা পর্যায়ে যে সব অফিসের চাহিদা আছে তার নামের তালিকা এবং কর্মকর্তা কর্মচারির সংখ্যা:</th>
                                            <th>ভবনের ছবি</th>
                                            <th>নির্মান সাল</th>
                                            <th>প্লিন্থ এরিয়া</th>
                                            <th>মোট ফ্লোর এরিয়া</th>
                                            <th>নির্বাহী কর্মকর্তার মতামত</th>
                                            <th>কোর্ট বিল্ডিং অপসারন করা না গেলে উপজেলা পরিষদ অঙ্গনে পর্যাপ্ত জায়গা আছে কিনা? থাকলে জমির পরিমান</th>
                                        </tr>
                                        
                                    </thead>
                                    <tbody>
					<?php 
					
					$user_id = array('1', '2','3', '4', '5','6', '7');
					
                    $sl = 0;
					$qur="SELECT tbl_court.*, tbl_upazila.UpazilaNameBn, hrtoffice.OfficeName, hrtoffice.OfficeNameBn
					from tbl_court 
					INNER JOIN tbl_upazila on tbl_upazila.ID=tbl_court.UpazilaID
					INNER JOIN hrtoffice on hrtoffice.OfficeID=tbl_court.OfficeID
					ORDER BY hrtoffice.OfficeName,tbl_upazila.OfficeID";
                    $query1 = mysqli_query($conn,$qur) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['OfficeNameBn']?></td>
<td><?=$result1['UpazilaNameBn']?></td>
<td><?=$result1['LandSize']?></td>
<td><?php echo $result1['OwenershipInfo']."<br>"; if($result1['OwenershipInfoFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['OwenershipInfoFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>

<td><?php echo $result1['DagKhatiyan']."<br>"; if($result1['DagKhatiyanFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['DagKhatiyanFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>

<td><?php echo $result1['LandTaxInfo']."<br>"; if($result1['LandTaxInfoFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['LandTaxInfoFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>
<td><?php if($result1['BuildingLocation']=='Yes') echo "হ্যাঁ"; else echo "না";?></td>
<td><?=$result1['OtherInstallationInfo']?></td>

<td><?php echo $result1['SurveyReport']."<br>"; if($result1['SurveyReportFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['SurveyReportFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>

<td><?=$result1['OtherOfficeNames']?></td>

<td><?php echo $result1['OtherOfficeDemand']."<br>"; if($result1['OtherOfficeDemandFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['OtherOfficeDemandFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>

<td><?php if($result1['BuildingPhotoFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['BuildingPhotoFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>

<td><?=$result1['EstablishYear']?></td>
<td><?=$result1['PlinthArea']?></td>
<td><?=$result1['FloorArea']?></td>

<td><?php echo $result1['UnoComment']."<br>"; if($result1['UnoCommentFile']) {?> <a href="http://pwd-ucop.com/documents/court/<?php echo $result1['UnoCommentFile'];?>" target="_blank"></a><?php }?></td>

<td><?=$result1['EmptySpace']?></td>
</tr>
                                    <?php } }?>
                                        
                                    </tbody>
                                </table>
                            