<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Uses of Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks </title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>
    <style>
	.space {
	width:100%; 
	height:15px;
	}
	.col-md-3 {
		font-size:12px !important;
	}
	
	/*.background {
		border:1px solid #ccc; padding:5px;
		background-color:#F8F8FA;
	}*/
	
	</style>
    


</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>
        
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
                


        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Add New Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="insert1.php" method="post" enctype="multipart/form-data" class="form-horizontal">


                        <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php }
		//$query = mysqli_query($conn, "SELECT * from tbl_assets where ID=".$_GET['asset']) or die(mysqli_error($conn));
       // $result=mysqli_fetch_array($query);
		
		?>
                        
                        
                        <div class="row form-group">
                        
                        
                       <!-- <div class="col-md-3"><label for="text-input" class=" form-control-label">১. Hollow Block ব্যবহারের সার্কুলার পেয়েছেন কিনা?<span style="color: red">*</span></label></div>
                            <div class="col-md-4" style="font-size:14px;"><input type="radio" id="Circular" name="Circular" placeholder="" value="1" checked>  হ্যা &nbsp;&nbsp;&nbsp;<input type="radio" id="Circular" name="Circular" placeholder="" value="0">না</div> 
                            
                            <div class="space"></div>-->
                            
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১. অর্থ বছর:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><select name="10InchCat" class="form-control">
                            <option value="2021-2022">২০২১-২০২২</option>
                            <option value="2022-2023">২০২২-২০২৩</option>
                            <option value="2023-2024">২০২৩-২০২৪</option>
                            </select>
                            
                            <small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            
                           
                           <div class="col-md-3"><label for="text-input" class=" form-control-label">২. কাজের নাম:<span style="color: red">*</span></label></div>
                            <div class="col-md-4">
                            
                            <textarea  type="text" id="NameOfTender" name="NameOfTender" placeholder="" class="form-control" required ></textarea>
                            ** ১ কোটি টাকার উর্ধ্বে উন্নয়ন মূলক কাজের নাম
                            <small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            <!--<div class="col-md-3"><label for="text-input" class=" form-control-label">৩. উক্ত কাজে Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহৃত হচ্ছে কিনা? <span style="color: red">*</span></label></div>
                            <div class="col-md-2" style="font-size:14px;"><input type="radio" id="IsHollowBlock" name="IsHollowBlock" placeholder="" value="1" checked>  হ্যা &nbsp;&nbsp;&nbsp;<input type="radio" id="IsHollowBlock" name="IsHollowBlock" placeholder="" value="0">না</div> 
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহৃত হলে কতগুলো Tender এ ব্যবহৃত হচ্ছে</label></div> 
                            <div class="col-md-2"><input type="text" id="NoOfHollowBlockTender" name="NoOfHollowBlockTender" placeholder="" class="form-control"><small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>-->
                            
                             <div class="col-md-3"><label for="text-input" class=" form-control-label">৩. কাজের মূল্য:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="TenderAmount" name="TenderAmount" placeholder="" class="form-control">
                            
                            <small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৪. উক্ত টেন্ডারের BOQ আপলোড করুন:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="file" id="BOQOfHollowBlock" name="BOQOfHollowBlock" placeholder="" class="form-control"><small class="form-text text-muted"></small></div>
                            
                            
                            
                            
                             <div class="space"></div>

<head>
    <title>JavaScript</title>
    <script type="text/javascript">
        function calculateTotal() {
        
            var val1 = document.getElementById('QuntOf10Inch').value;
            var val2 = document.getElementById('QuntOf10InchHollowBlock').value;
            var total = val1 - val2;
    
            document.getElementById('QuntOf10InchHollowBlock2').value = total;
        }

        function calculateTotal1() {
        
            var val1 = document.getElementById('QuntOf5Inch').value;
            var val2 = document.getElementById('QuntOf5InchHollowBlock').value;
            var total = val1 - val2;
    
            document.getElementById('QuntOf5InchHollowBlock2').value = total;
        }

        function calculateTotal2() {
        
            var val1 = document.getElementById('QuntOfHering').value;
            var val2 = document.getElementById('QuntOfHeringHollowBlock').value;
            var total = val1 - val2;
    
            document.getElementById('QuntOfHeringHollowBlock2').value = total;
        }

    </script>
</head>

<div class="col-md-3"><label for="text-input" class=" form-control-label">৫. টেন্ডারে ১০'' ইটের গাথুনীর তথ্য (m3):</label></div>
<div class="col-md-3">টেন্ডারে ১০'' ইটের মোট গাথুনী কতটুকু ?<input type="text" id="QuntOf10Inch" onchange="calculateTotal()" name="QuntOf10Inch" placeholder="" class="form-control"> <br> 
Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা <textarea  type="text" id="NameOfTender" name="NameOfTender" placeholder="" class="form-control" required ></textarea>

</div>
<div class="col-md-3">
Non Fired Hollow Brick এর গাথুনী কতটুকু ?
<input type="text" id="QuntOf10InchHollowBlock" onchange="calculateTotal()" name="QuntOf10InchHollowBlock" placeholder="" class="form-control"> <br>
Non Fired Hollow Brick ব্যবহারের বাস্তবায়নের অগ্রগতি (%)
<input type="text" id="QuntOf10InchHollowBlock"  name="QuntOf10InchHollowBlock" placeholder="" class="form-control" >
</div>

<div class="col-md-3">
Fired Brick এর গাথুনী কতটুকু ?
<input type="text" id="QuntOf10InchHollowBlock2"  name="QuntOf10InchHollowBlock2" placeholder="" class="form-control" disabled> 
</div>


                             
                            
                            
                            
                            
                             <div class="space"></div>
                              <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৬. টেন্ডারে  ৫'' ইটের গাথুনীর তথ্য (m3):</label></div>
                            
                            

<div class="col-md-3">টেন্ডারে ৫'' ইটের মোট গাথুনী কতটুকু ?<input type="text" id="QuntOf5Inch" onchange="calculateTotal1()" name="QuntOf5Inch" placeholder="" class="form-control"> <br> Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা <textarea  type="text" id="NameOfTender" name="NameOfTender" placeholder="" class="form-control" required ></textarea>
</div>
<div class="col-md-3">
Non Fired Hollow Brick এর গাথুনী কতটুকু ?
<input type="text" id="QuntOf5InchHollowBlock" onchange="calculateTotal1()" name="QuntOf5InchHollowBlock" placeholder="" class="form-control"> <br>
Non Fired Hollow Brick ব্যবহারের বাস্তবায়নের অগ্রগতি (%)
<input type="text" id="QuntOf5InchHollowBlock" name="QuntOf5InchHollowBlock" placeholder="" class="form-control">
</div>

<div class="col-md-3">
Fired Brick এর গাথুনী কতটুকু ?
<input type="text" id="QuntOf5InchHollowBlock2" name="QuntOf5InchHollowBlock2" placeholder="" class="form-control" disabled> 
</div>


                            
                            
                            
                            
                            <div class="space"></div>
                            <div class="space"></div>
                            


<div class="col-md-3"><label for="text-input" class=" form-control-label">৭. টেন্ডারে হেরিং বোন ইটের রাস্তার পরিমান কতটুকু ? (sft) :</label></div>

<div class="col-md-3">হেরিং বোন ইটের রাস্তার পরিমান কতটুকু?<input type="text" id="QuntOfHering" onchange="calculateTotal2()" name="QuntOfHering" placeholder="" class="form-control"> <br> Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা <textarea  type="text" id="NameOfTender" name="NameOfTender" placeholder="" class="form-control" required ></textarea>
</div>
<div class="col-md-3">
Non Fired Solid Brick এর পরিমান কতটুকু ?
<input type="text" id="QuntOfHeringHollowBlock" onchange="calculateTotal2()" name="QuntOfHeringHollowBlock" placeholder="" class="form-control"> <br>
Non Fired Solid Brick ব্যবহারের বাস্তবায়নের অগ্রগতি (%)
<input type="text" id="QuntOfHeringHollowBlock" name="QuntOfHeringHollowBlock" placeholder="" class="form-control">
</div>

<div class="col-md-3">
Fired Brick এর পরিমান কতটুকু ?
<input type="text" id="QuntOfHeringHollowBlock2" name="QuntOfHeringHollowBlock2" placeholder="" class="form-control" disabled> 
</div>

                            
                            <div class="space"></div>
                            
                            <!--<div class="col-md-3"><label for="text-input" class=" form-control-label">৮. Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহার না হলে তার কারণ?:</label></div>
                            <div class="col-md-4"><textarea  type="text" id="Remarks" name="Remarks" placeholder="" class="form-control"></textarea></div> -->
                            
                            
                            
                            



 
                   </div> 
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Submit
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <?php include 'js_master.php';?>
    <script src="jquery.min.js"></script>
        <script>
$(document).ready(function(){
  $("#nobtn").click(function(){
    $("#test1").text("উপজেলা পরিষদ ক্যাম্পাসের ডিজিটাল সার্ভে রিপোর্ট:");
  });
  $("#yesbtn").click(function(){
    $("#test1").text("কোর্ট বিল্ডিংয়ের পারিপার্শ্বিক ভবন ও রাস্তাসহ ডিজিটাল সার্ভে রিপোর্ট");
  });
});
</script>

</body>



</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>