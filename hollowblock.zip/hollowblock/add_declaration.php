<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Uses of Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks </title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>
    <style>
	.space {
	width:100%; 
	height:15px;
	}
	.col-md-3 {
		font-size:12px !important;
	}
	/*.background {
		border:1px solid #ccc; padding:5px;
		background-color:#F8F8FA;
	}*/
	
	</style>
    


</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>
        
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
                


        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Add New Information</strong> 
                </div>
                <div class="card-body card-block">
                   


                        <?php 
						
$query=mysqli_query($conn, "SELECT ID from tbl_information WHERE OfficeID=".$_SESSION["OfficeID"]." ORDER BY ID DESC LIMIT 1");
$result=mysqli_fetch_array($query);
if($result){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert" style="font-size:15px; font-weight:bold;">
                    You are already given your declaration
                    
                </div>
            </div>
            
            <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                         
                                            <th>Hollow Block ব্যবহারের সার্কুলার পেয়েছেন কিনা?</th>
                                            <th> কতগুলো কাজের দরপত্র আহবান করা হয়েছে।</th>
                                            <th>উক্ত কাজে Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহৃত হচ্ছে কিনা? হলে কতগুলো Tender এ ব্যবহৃত হচ্ছে?</th>
                                            
                                            <th>Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহার না হলে তার কারণ?</th>
                                            
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_information where  IsActive=1 AND OfficeID=".$_SESSION['OfficeID']) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++; 
                        ?>
<tr>
<td><?php if($result1['Circular']==1) echo 'হ্যা'; else echo 'না';?></td>
<td><?php echo $result1['NoOfTender'];?></td>
<td><?php if($result1['IsHollowBlock']==1) echo 'হ্যা'; else echo 'না';?> <br> <?php echo $result1['NoOfHollowBlockTender'];?></td>

<td><?php echo $result1['Remarks'];?></td>
</tr>
                                    <?php } ?>
                                        
                                    </tbody>
                                </table>

        <?php } else {
		
		
		?>
              <form action="insert_declaration.php" method="post" enctype="multipart/form-data" class="form-horizontal">           
                        
                        <div class="row form-group">
                        
                        
                       <div class="col-md-3"><label for="text-input" class=" form-control-label">১. Hollow Block ব্যবহারের সার্কুলার পেয়েছেন কিনা?<span style="color: red">*</span></label></div>
                            <div class="col-md-4" style="font-size:14px;"><input type="radio" id="Circular" name="Circular" placeholder="" value="1" checked>  হ্যা &nbsp;&nbsp;&nbsp;<input type="radio" id="Circular" name="Circular" placeholder="" value="0">না</div> 
                            
                            <div class="space"></div>
                            
                            
                             <div class="col-md-3"><label for="text-input" class=" form-control-label">২. কতগুলো কাজের দরপত্র আহবান করা হয়েছে:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="NoOfTender" name="NoOfTender" placeholder="" class="form-control" required><small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৩. উক্ত কাজে Non Fired (Concrete/Sand-Cement) Hollow Brick / Non Fired Solid Brick ব্যবহৃত হচ্ছে কিনা? <span style="color: red">*</span></label></div>
                            <div class="col-md-2" style="font-size:14px;"><input type="radio" id="IsHollowBlock" name="IsHollowBlock" placeholder="" value="1" checked>  হ্যা &nbsp;&nbsp;&nbsp;<input type="radio" id="IsHollowBlock" name="IsHollowBlock" placeholder="" value="0">না</div> 
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">Non Fired (Concrete/Sand-Cement) Hollow Brick / Non Fired Solid Brick ব্যবহৃত হলে কতগুলো Tender এ ব্যবহৃত হচ্ছে</label></div> 
                            <div class="col-md-2"><input type="text" id="NoOfHollowBlockTender" name="NoOfHollowBlockTender" placeholder="" class="form-control"><small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                           
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৪. Non Fired (Concrete/Sand-Cement) Hollow Brick / Non Fired Solid Brick ব্যবহার না হলে তার কারণ?:</label></div>
                            <div class="col-md-4"><textarea  type="text" id="Remarks" name="Remarks" placeholder="" class="form-control"></textarea></div>
                            
                            
                            
                            



 
                   </div> 
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Submit
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>
                <?php } ?>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <?php include 'js_master.php';?>
    <script src="jquery.min.js"></script>
        <script>
$(document).ready(function(){
  $("#nobtn").click(function(){
    $("#test1").text("উপজেলা পরিষদ ক্যাম্পাসের ডিজিটাল সার্ভে রিপোর্ট:");
  });
  $("#yesbtn").click(function(){
    $("#test1").text("কোর্ট বিল্ডিংয়ের পারিপার্শ্বিক ভবন ও রাস্তাসহ ডিজিটাল সার্ভে রিপোর্ট");
  });
});
</script>

</body>



</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>