<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Uses of Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks </title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>
    <style>
	
	body .main-body {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}

	.space {
	width:100%; 
	height:15px;
	}
	.col-md-3 {
		font-size:12px !important;
	}
	
    #NameOfTender {
        text-align: left !important;
    }

	/*.background {
		border:1px solid #ccc; padding:5px;
		background-color:#F8F8FA;
	}*/
	
	</style>
    


</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>
        
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
                


        <div class="col-md-12 main-body">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="update.php" method="post" enctype="multipart/form-data" class="form-horizontal">


                        <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php }
		$query = mysqli_query($conn, "SELECT * from tbl_information_new where ID=".$_GET['id']) or die(mysqli_error($conn));
       $result1=mysqli_fetch_array($query);
		?>
                        
                        
                        <div class="row form-group">
                        
                        
                       <!-- <div class="col-md-3"><label for="text-input" class=" form-control-label">১. Hollow Block ব্যবহারের সার্কুলার পেয়েছেন কিনা?<span style="color: red">*</span></label></div>
                            <div class="col-md-4" style="font-size:14px;"><input type="radio" id="Circular" name="Circular" placeholder="" value="1" checked>  হ্যা &nbsp;&nbsp;&nbsp;<input type="radio" id="Circular" name="Circular" placeholder="" value="0">না</div> 
                            
                            <div class="space"></div>-->
                            
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">১. অর্থ বছর:<span style="color: red">*</span></label></div>
                            <input type="hidden" name="InfoID" value="<?php echo $_GET['id'];?>">
                            <div class="col-md-4"><select name="FinancialYear" class="form-control">
                            <option value="2022-2023" <?php if($result1['FinancialYear']=='2022-2023') echo "selected";?>>2022-2023</option>
                            <option value="2023-2024" <?php if($result1['FinancialYear']=='2023-2024') echo "selected";?>>2023-2024</option>
                            </select>
                            
                            <small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            
                           
                           <div class="col-md-3"><label for="text-input" class=" form-control-label">২. কাজের নাম:<span style="color: red">*</span></label></div>
                            <div class="col-md-4">
                            
                            <textarea  type="text" id="NameOfTender" name="NameOfTender" placeholder="" class="form-control align-left" required >
							<?php echo $result1['NameOfTender']; ?></textarea>
                            
                            <small class="form-text text-muted"></small></div> 
             
                            <div class="space"></div>
                            
                            <!--<div class="col-md-3"><label for="text-input" class=" form-control-label">৩. উক্ত কাজে Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহৃত হচ্ছে কিনা? <span style="color: red">*</span></label></div>
                            <div class="col-md-2" style="font-size:14px;"><input type="radio" id="IsHollowBlock" name="IsHollowBlock" placeholder="" value="1" checked>  হ্যা &nbsp;&nbsp;&nbsp;<input type="radio" id="IsHollowBlock" name="IsHollowBlock" placeholder="" value="0">না</div> 
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহৃত হলে কতগুলো Tender এ ব্যবহৃত হচ্ছে</label></div> 
                            <div class="col-md-2"><input type="text" id="NoOfHollowBlockTender" name="NoOfHollowBlockTender" placeholder="" class="form-control"><small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>-->
                            
                             <div class="col-md-3"><label for="text-input" class=" form-control-label">৩. কাজের মূল্য (লক্ষ্য টাকায়):<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><input type="text" id="TenderAmount" name="TenderAmount" placeholder="" class="form-control" value="<?php echo $result1['TenderAmount']; ?>">
                            
                            <small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            
                            
<div class="col-md-3"><label for="text-input" class=" form-control-label">৪. উক্ত টেন্ডারের BOQ আপলোড করুন:<span style="color: red">*</span></label></div>
<div class="col-md-4"><input type="file" id="BOQOfHollowBlock" name="BOQOfHollowBlock"class="form-control">

<?php if($result1['BOQOfHollowBlock']!='') { ?><small class="form-text text-muted"><a href="<?php echo $result1['BOQOfHollowBlock']; ?>" target="_blank">View BOQ</a></small> <?php } ?>


</div>
                            
                            
                            
                            
                            
                             <div class="space"></div>
                             
                              <div class="col-md-3"><label for="text-input" class=" form-control-label">৫. কাজটি সমাপ্ত কিনা?:<span style="color: red">*</span></label></div>
                            <div class="col-md-4"><select name="WorkDone" class="form-control">
                            <option value="">নির্বাচন করুন</option>
                            <option value="1" <?php if($result1['WorkDone']==1) echo "Selected";?>> হ্যা </option>
                            <option value="0" <?php if($result1['WorkDone']==0) echo "Selected";?>>না </option>
                            </select>
                            
                            <small class="form-text text-muted"></small></div> 
                            
                            <div class="space"></div>
                            
                            
                            

                             <head>

<title>JavaScript</title>
<script type="text/javascript">

    function calculateTotal() {
    
        var val1 = document.getElementById('QuntOf10Inch').value;
        var val2 = document.getElementById('QuntOf10InchBlock').value;
        var total = val1 - val2;

        document.getElementById('OuntOf10Inchfired').value = total;
    }

    function calculateTotal1() {
    
        var val1 = document.getElementById('QuntOf5Inch').value;
        var val2 = document.getElementById('QuntOf5InchBlock').value;
        var total = val1 - val2;

        document.getElementById('OuntOf5Inchfired').value = total;
    }

    function calculateTotal2() {
    
        var val1 = document.getElementById('QuntOfHering').value;
        var val2 = document.getElementById('QuntOfHeringBlock').value;
        var total = val1 - val2;

        document.getElementById('OuntOfHeringfired').value = total;
    }

</script>
</head>

<div class="col-md-3"><label for="text-input" class=" form-control-label">৫. টেন্ডারে ১০'' গাথুনীর তথ্য (m3):</label></div>
<div class="col-md-3">টেন্ডারে ১০'' ব্লকের গাথুনী কতটুকু ?<input type="text" id="QuntOf10Inch" onchange="calculateTotal()" name="QuntOf10Inch" placeholder="" class="form-control" value="<?php echo $result1['QuntOf10Inch']; ?>">
<br>
Non Fired ব্লক ব্যবহারের বাস্তবায়নের অগ্রগতি (m3)
<input type="text" id="ProOf10InchBlock" name="ProOf10InchBlock" placeholder="" class="form-control" value="<?php echo $result1['ProOf10InchBlock']; ?>">


</div>
<div class="col-md-3">
Non Fired ব্লকের গাথুনী কতটুকু ?
<input type="text" id="QuntOf10InchBlock" onchange="calculateTotal()" name="QuntOf10InchBlock" placeholder="" class="form-control" value="<?php echo $result1['QuntOf10InchBlock']; ?>">
 <br> Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা <textarea  type="text" id="ReaOf10InchFired" name="ReaOf10InchFired" placeholder="" class="form-control" required ><?php echo $result1['ReaOf10InchFired']; ?></textarea>
  
</div>

<div class="col-md-3">
Fired Brick এর গাথুনী কতটুকু ?
<input type="text" id="OuntOf10Inchfired" name="OuntOf10Inchfired" placeholder="" class="form-control" value="<?php echo $result1['OuntOf10Inchfired']; ?>" readonly> 
</div>


                             
                            
                            
                            
                            
                             <div class="space"></div>
                              <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">৬. টেন্ডারে  ৫'' গাথুনীর তথ্য (sqm):</label></div>
                            
                            
<div class="col-md-3">টেন্ডারে ৫'' মোট গাথুনী কতটুকু ?<input type="text" id="QuntOf5Inch" onchange="calculateTotal1()" name="QuntOf5Inch" placeholder="" class="form-control" value="<?php echo $result1['QuntOf5Inch']; ?>"> 

<br>
Non Fired ব্লক ব্যবহারের বাস্তবায়নের অগ্রগতি (sqm)
<input type="text" id="ProOf5InchBlock" name="ProOf5InchBlock" placeholder="" class="form-control" value="<?php echo $result1['ProOf5InchBlock']; ?>">
</div>
<div class="col-md-3">
Non Fired ব্লকের গাথুনী কতটুকু ?
<input type="text" id="QuntOf5InchBlock" onchange="calculateTotal1()" name="QuntOf5InchBlock" placeholder="" class="form-control" value="<?php echo $result1['QuntOf5InchBlock']; ?>">
<br> Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা <textarea  type="text" id="ReaOf5InchFired" name="ReaOf5InchFired" placeholder="" class="form-control" required ><?php echo $result1['ReaOf5InchFired']; ?></textarea>
</div>

<div class="col-md-3">
Fired Brick এর গাথুনী কতটুকু ?
<input type="text" id="OuntOf5Inchfired" name="OuntOf5Inchfired" placeholder="" class="form-control" value="<?php echo $result1['OuntOf5Inchfired']; ?>" readonly> 
</div>


                            
                            
                            
                            
                            <div class="space"></div>
                            <div class="space"></div>
                            
<div class="col-md-3"><label for="text-input" class=" form-control-label">৭. টেন্ডারে রাস্তায় ব্যবহৃত ব্লক/ইট এর পরিমান কতটুকু (Sqm) :</label></div>

<div class="col-md-3">রাস্তায় ব্লকের এবং ইটের পরিমান কতটুকু?<input type="text" id="QuntOfHering" onchange="calculateTotal2()" name="QuntOfHering" placeholder="" class="form-control"value="<?php echo $result1['QuntOfHering']; ?>">

<br>
Non Fired ব্লক ব্যবহারের বাস্তবায়নের অগ্রগতি (Sqm)
<input type="text" id="ProOfHeringBlock" name="ProOfHeringBlock" placeholder="" class="form-control" value="<?php echo $result1['ProOfHeringBlock']; ?>">


</div>
<div class="col-md-3">
Non Fired ব্লকের পরিমান কতটুকু ?
<input type="text" id="QuntOfHeringBlock" onchange="calculateTotal2()" name="QuntOfHeringBlock" placeholder="" class="form-control" value="<?php echo $result1['QuntOfHeringBlock']; ?>"> 
 <br> Fired Brick ব্যবহৃত হলে তার যৌক্তিকতা <textarea  type="text" id="ReaOfHeringFired" name="ReaOfHeringFired" placeholder="" class="form-control" required ><?php echo $result1['ReaOfHeringFired']; ?></textarea>
</div>

<div class="col-md-3">
Fired Brick এর পরিমান কতটুকু ?
<input type="text" id="OuntOfHeringfired" name="OuntOfHeringfired" placeholder="" class="form-control" value="<?php echo $result1['OuntOfHeringfired']; ?>" readonly> 
</div>

                            
                            <div class="space"></div>
                            
                            
                             <div class="col-md-3"><label class="form-label">৮. ছবি নির্বাচন করুন: </label></div>
<div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image1" class="form-control rounded-0 border-info formFileMultiple" name="Image1">
<small class="form-text text-muted"><a href="<?php echo $result1['Image1']; ?>" target="_blank">View Image</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image1Caption" name="Image1Caption" class="form-control" value="<?php echo $result1['Image1Caption']; ?>" ></div>
<div class="space"></div>


<div class="col-md-3"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image2" class="form-control rounded-0 border-info formFileMultiple" name="Image2">
<small class="form-text text-muted"><a href="<?php echo $result1['Image2']; ?>" target="_blank">View Image</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image2Caption" name="Image2Caption" class="form-control" value="<?php echo $result1['Image2Caption']; ?>" ></div>
<div class="space"></div>


<div class="col-md-3"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image3" class="form-control rounded-0 border-info formFileMultiple" name="Image3">
<small class="form-text text-muted"><a href="<?php echo $result1['Image3']; ?>" target="_blank">View Image</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image3Caption" name="Image3Caption" class="form-control" value="<?php echo $result1['Image3Caption']; ?>" ></div>
<div class="space"></div>


<div class="space"></div>


<div class="col-md-3"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image4" class="form-control rounded-0 border-info formFileMultiple" name="Image4">
<small class="form-text text-muted"><a href="<?php echo $result1['Image4']; ?>" target="_blank">View Image</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image4Caption" name="Image4Caption" class="form-control" value="<?php echo $result1['Image4Caption']; ?>" ></div>
<div class="space"></div>

<div class="col-md-3"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image5" class="form-control rounded-0 border-info formFileMultiple" name="Image5">
<small class="form-text text-muted"><a href="<?php echo $result1['Image5']; ?>" target="_blank">View Image</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image5Caption" name="Image5Caption" class="form-control" value="<?php echo $result1['Image5Caption']; ?>" ></div>
<div class="space"></div>
                            
                            <!--<div class="col-md-3"><label for="text-input" class=" form-control-label">৮. Hollow Block / Concrete / Sand Cement Block/ Non Fired Bricks ব্যবহার না হলে তার কারণ?:</label></div>
                            <div class="col-md-4"><textarea  type="text" id="Remarks" name="Remarks" placeholder="" class="form-control"></textarea></div> -->
                            
                            
                            
                            



 
                   </div> 
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Update Now
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <?php include 'js_master.php';?>
    <script src="jquery.min.js"></script>
        <script>
$(document).ready(function(){
  $("#nobtn").click(function(){
    $("#test1").text("উপজেলা পরিষদ ক্যাম্পাসের ডিজিটাল সার্ভে রিপোর্ট:");
  });
  $("#yesbtn").click(function(){
    $("#test1").text("কোর্ট বিল্ডিংয়ের পারিপার্শ্বিক ভবন ও রাস্তাসহ ডিজিটাল সার্ভে রিপোর্ট");
  });
});
</script>

</body>



</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>