<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (ERP) for Co-ordination</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dengue Protection Monitoring System</h1>
                    </div>
                </div>
            </div>
            
        </div>

        
            
         <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!--01. All the ponds / reservoirs / lakes / canals under the Public Works Department have been cleared and cleaned -->০১। গণপূর্ত অধিদপ্তরের আওতাধীন সকল পুকুর/জলাশয়/লেক/খাল কচুরীপানা মুক্ত ও পরিষ্কার পরিচ্ছন্ন করা হয়েছে।</strong> 
<?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 1 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=1" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=1" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
					$query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 1 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));					
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:15px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!--02. Necessary steps have been taken to remove waste from all installations under the Public Works Department.--> ০২। গণপূর্ত অধিদপ্তরের আওতাধীন সকল স্থাপনার বর্জ অপসারণের বিষয়ে প্রয়োজনীয় ব্যবস্থা গ্রহণ করা হয়েছে।</strong> 
<?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 2 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=2" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=2" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 2 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:20px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
                <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!--03. Measures have been taken to keep the drains and adjoining areas of all government hospitals clean and tidy under the Public Works Department.--> ০৩। গণপূর্ত অধিদপ্তরের আওতায় সকল সরকারি হাসপাতালের ড্রেইন এবং তৎসংলগ্ন এলাকা পরিষ্কার পরিচ্ছন্ন রাখার ব্যবস্থা গ্রহণ করা হয়েছে।</strong> &nbsp;&nbsp;&nbsp; 
<?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 3 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=3" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=3" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 3 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:20px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!--04. All office, courts and courtyards are kept free of bushes and weeds, adjacent roads and drains are also being cleaned regularly.--> ০৪। সকল অফিস আদালত ও বাসা বাড়ির আঙ্গিনার ঝোঁপ-ঝাড় ও আগাছা মুক্ত রাখা, সংলগ্ন রাস্তা, ড্রেইন নিয়মিত পরিষ্কার করা হচ্ছে।</strong> &nbsp;&nbsp; <?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 4 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=4" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=4" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 4 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:20px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> 
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!--05. All sources of stagnant water are being removed as much as possible and regular spraying of disinfectants, floating larvae are being destroyed. --> ০৫। জমানো পানির সকল উৎস যথাসম্ভব অপসারণ পূর্বক নিয়মিতভাবে জীবানু-নাশক ছিটানোর ব্যবস্থা ও পানিতে ভাসমান লার্ভা বিনষ্ট করা হচ্ছে। </strong> &nbsp;&nbsp; <?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 5 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=5" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=5" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 5 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:20px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!-- 06. Regular Measures have been taken to spray mosquito larvae destroying disinfectants in the water stored in the building for casting.--> ০৬। ভবনের ঢালাইয়ের কিউরিং কাজে জমানো পানিতে মশার লার্ভা ধ্বংসকারী ওষধ নিয়মিতভাবে ছিটানোর ব্যবস্থা গ্রহণ করা হয়েছে।</strong> &nbsp;&nbsp; <?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 6 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=6" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=6" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 6 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:20px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title"><!--07. Unnecessary stagnant water has been removed at construction sites under all Public Works Departments.--> ০৭। সকল গণপূর্ত বিভাগের আওতাধীন নির্মাণ সাইটগুলোতে অপ্রয়োজনীয় আবদ্ধ পানি অপসারণ করা হয়েছে।  </strong> &nbsp;&nbsp; 
                                <?php 
$query = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 7 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=1") or die(mysqli_error($conn));
$result=mysqli_fetch_array($query);
if(!$result) {
?>
&nbsp;&nbsp;&nbsp; প্রযোজ্য না হলে <a href="insert1.php?type=na&Asset=7" style="text-decoration:underline; color:blue;">ক্লিক করুন</a> &nbsp;&nbsp;&nbsp;<a href="add_report.php?asset=7" style="float:right; color:green; font-weight:bold;">Add New</a>
<?php } else { ?> 
<span style="float:right; color:red; font-weight:bold;">প্রযোজ্য নহে </span>
<?php }?>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Structure</th>
                                            <th>Date of Completion</th>
                                            <th>Image 01</th>
                                            <th>Image 02</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_workrecord where AssetTypeID = 7 AND OfficeID=".$_SESSION['OfficeID']." AND IsNA=0") or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['AssetName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="images/dengu/<?=$result1['Image1']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image1']?></a></td>
<td><a href="images/dengu/<?=$result1['Image2']?>" target="_blank" style="text-decoration:underline;"><?=$result1['Image2']?></a></td>
<td><a href="delete.php?workid=<?php echo $result1['ID'];?>" style="color:red; font-size:20px; text-align:center; font-weight:bold;">X</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    

    <!-- Right Panel -->


    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
