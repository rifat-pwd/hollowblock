  <?php 

  //include("config/connection.php");

    //$sidebar_process = mysqli_query($conn, "SELECT * from tbl_process") or die(mysqli_error($conn));

  ?>

  <style type="text/css">
      .navbar .navbar-brand, .navbar .menu-title{

        border-bottom: 1px solid #9496a1 !important;
      }

      
  </style>

  <aside id="left-panel" class="left-panel" style="background-color: #8247b3">
        <nav class="navbar navbar-expand-sm navbar-default" style="background-color: #8247b3">   <!-- #8247b3 --> <!-- #873d6c -->

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a href="home.php"><img src="assets/images/favicon.png" alt="Logo" width="80"></a>
                <a class="navbar-brand" href="home.php" style="font-size: 14px; padding-top:0px !important;">Public Works Department (PWD)</a>
             
               
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                
                
               <?php  if($_SESSION['UserID']==55) {?>
                
                 <li class="">
                        <a href="all_division.php"> <i class="menu-icon fa fa-tasks"></i>Block Information</a>
                        <a href="all_division1.php"> <i class="menu-icon fa fa-tasks"></i>Pond Information</a>
                        <a href="all_division2.php"> <i class="menu-icon fa fa-tasks"></i>Tree Information</a>

                        
                    </li>
                
               <?php  } ?>
                  
                    
                   
                    <?php if($_SESSION['UserID']!=55) {?>
                    
                    <li class="active">
                        <a href="home.php"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    
                    <h3 class="menu-title">Block Information</h3>
                    
                    <!--<li class="">
                        <a href="resources.php" > <i class="menu-icon fa fa-tasks"></i>Add Upazila</a>
                        
                    </li>-->
                    
                     <li class="">
                        <a href="add_report.php"> <i class="menu-icon fa fa-tasks"></i>Add Information</a>
                        
                        <a href="images/Non-Fire brick-image-selected.zip" target="_blank"> <i class="menu-icon fa fa-tasks"></i>Sample Images</a>

                        <!--<a href="add_declaration.php" > <i class="menu-icon fa fa-tasks"></i>Declaration Form</a>-->
                        
                        
                        
                    </li>
                    
                    <h3 class="menu-title">Pond Information</h3>
                    
                    <li class="">
                        
                        <a href="view_pond.php"> <i class="menu-icon fa fa-tasks"></i>View Information</a>
                        <a href="add_pond.php"> <i class="menu-icon fa fa-tasks"></i>Add Information</a>
                        
                    </li>

                    <h3 class="menu-title">Tree Information</h3>
                    
                    <li class="">
                        
                        <a href="view_tree.php"> <i class="menu-icon fa fa-tasks"></i>View Information</a>
                        <a href="add_tree.php"> <i class="menu-icon fa fa-tasks"></i>Add Information</a>
                        
                    </li>
					
                    
                    <?php  } ?>
                    
                    <!-- if($_SESSION['UserID']==55) {
                    <h3 class="menu-title">Reports</h3>
                    <li class="">
                        <a href="all_division.php"> <i class="menu-icon fa fa-tasks"></i>List of Offices</a>
                        
                    </li>
                    <!--<li class="">
                        <a href="all_reports.php" target="_blank"> <i class="menu-icon fa fa-tasks"></i>List of Information</a>
                        
                    </li>
                    
                    <li class="">
                        <a href="all_divisions_info.php" target="_blank"> <i class="menu-icon fa fa-tasks"></i>List of Offices</a>
                        
                    </li>
                     } -->
                    

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel