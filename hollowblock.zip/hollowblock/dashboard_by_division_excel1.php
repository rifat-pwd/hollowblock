<?php 
session_start();
if ($_SESSION['flag']=='ok') {
    include("config/connection.php");

    header("Content-type: application/vnd.ms-excel; name='excel'");
    header("Content-Disposition: attachment; filename=pond-info.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (ERP) for Co-ordination</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php //include 'css_master.php';?>

</head>

<body>

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php 
        $result = mysqli_query($conn, "SELECT ".DBHR.".hrtoffice.OfficeName FROM ".DBHR.".hrtoffice 
                                       WHERE ".DBHR.".hrtoffice.OfficeID=".$_GET['officeid']) or die(mysqli_error($conn));
        $row = mysqli_fetch_array($result);
        ?>

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php echo $row['OfficeName']; ?></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title" style="color:green;">View Information</strong> 
                </div>
                <div class="card-body">
                    <table style="font-size:12px; width:1200px; border:1px solid #000;" border="1">
                        <thead>
                            <tr>
                                <th rowspan="2">ক্রম</th>
                                <th rowspan="2">জলাশয়, পুকুর, দীঘি, হ্রদ</th>
                                <th colspan="4">জলাশয় পরিচিতি (হাল বছর)</th>  
                                <th rowspan="2">পুকুরের আয়তন (দৈর্ঘ্যxপ্রস্থxগভীরতা)</th>
                                <th rowspan="2">মৎস্য চাষের উপযুক্ততা</th>
                                <th rowspan="2">মন্তব্য</th>
                                <th rowspan="2">অনুপযুক্ত হলে করণীয়</th>
                                <th rowspan="2">ছবি</th>
                            </tr>
                            <tr>
                                <th>মৌজার নাম</th>
                                <th>খতিয়ান নং</th>
                                <th>দাগ নং</th>
                                <th>জমির পরিমাণ (শতাংশ)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $sl = 0;
                            $query = "SELECT * from tbl_pond where OfficeID='" . $_GET['officeid'] . "'";
                            $query1 = mysqli_query($conn, $query) or die(mysqli_error($conn));
                            while ($row = mysqli_fetch_array($query1)) {
                                $sl++; 
                                echo "<tr>";
                                echo "<td>".$sl."</td>";
                                echo "<td>".$row['PondName']."</td>";
                                echo "<td>".$row['MouzaName']."</td>";
                                echo "<td>".$row['KhatianNo']."</td>";
                                echo "<td>".$row['DagNo']."</td>";
                                echo "<td>".$row['LandAmount']."</td>";
                                echo "<td>".$row['PondDimension']."</td>";
                                echo "<td>";
                                if ($row['SuitableFishery'] == 1) {
                                    echo "উপযুক্ত";
                                } else {
                                    echo "অনুপযুক্ত";
                                }
                                echo "</td>";
                                echo "<td>".$row['Comments']."</td>";
                                echo "<td>".$row['ToDo']."</td>";
                                echo "<td><a href='view_pond1.php?id=".$row['ID']."' target='_blank'>View Images</a></td>";
                                echo "</tr>";
                            } 
                            ?>        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    <!-- Right Panel -->

    <?php include 'js_master.php'; ?>

</body>

</html>

<?php 
} elseif ($_SESSION["flag"] == "error_pass") {
    $msg = "The password is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "captcha") {
    $msg = "Your given number is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "error_username") {
    $msg = "The username is incorrect!";
    header("Location: index.php?msg=".$msg);
} else {
    $msg = "The username and password are incorrect!";
    header("Location: index.php?msg=".$msg);
}
?>