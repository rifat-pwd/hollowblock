<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Edit Pond</title>
    <meta name="description" content="Edit Data">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">
    <?php include 'css_master.php';?>
    <style>
    body .main-body {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}
body .main-body .col-md-3 {
	font-family:Nikosh !important;
	font-size:16px !important;
	font-weight:normal !important;
}
	.space {
	width:100%; 
	height:15px;
	}
	.col-md-3 {
		font-size:12px !important;
	}
	
	</style>

</head>

<body>
    <?php include 'sidebar.php';?>
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <?php include 'navbar.php';?>
        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-12  main-body">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="update_pond.php" method="post" enctype="multipart/form-data" class="form-horizontal">


                        <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php }
		$query = mysqli_query($conn, "SELECT * from tbl_pond where ID=".$_GET['id']) or die(mysqli_error($conn));
        $result1=mysqli_fetch_array($query);
		?>
                        
<div class="row form-group">

<div class="col-md-3"><label for="text-input" class=" form-control-label">জলাশয়, পুকুর, দীঘি, হ্রদ:<span style="color: red">*</span></label></div>
<div class="col-md-6">
    <input type="hidden" name="ID" value="<?php echo $_GET['id']; ?>">  
<input type="text" id="PondName" name="PondName" placeholder="" class="form-control align-left" value="<?php echo $result1['PondName']; ?>"></textarea>
<small class="form-text text-muted"></small></div> 
</div>  
<div class="space"></div>

                             
<div class="row form-group"> 
                             
<div class="col-md-3"><label for="text-input" class=" form-control-label">জলাশয় পরিচিতি (হাল বছর):<span style="color: red">*</span></label></div>
                             
                             
 <div class="col-md-2">
মৌজার নাম:
<input type="text" id="MouzaName" name="MouzaName" placeholder="" class="form-control" value="<?php echo $result1['MouzaName']; ?>" > 
</div>
<div class="col-md-2">
দাগ নং:
 <input type="text" id="DagNo" name="DagNo" placeholder="" class="form-control" value="<?php echo $result1['DagNo']; ?>" >
 </div>

<div class="col-md-2">
 খতিয়ান নং:
 <input type="text" id="KhatianNo" name="KhatianNo" placeholder="" class="form-control" value="<?php echo $result1['KhatianNo']; ?>" >
 </div>
 <div class="col-md-2">
জমির পরিমাণ (শতাংশ):
 <input type="text" id="LandAmount" name="LandAmount" placeholder="" class="form-control" value="<?php echo $result1['LandAmount']; ?>" > 
 </div>
 </div>
 <div class="space"></div>

<div class="row form-group"> 

 <div class="col-md-3"><label for="text-input" class=" form-control-label">পুকুরের আয়তন (দৈর্ঘ্যxপ্রস্থxগভীরতা):<span style="color: red">*</span></label></div>
   
<div class="col-md-2">
দৈর্ঘ্য:
<input type="text" id="PondLength" name="PondLength" placeholder="" class="form-control" value="<?php echo $result1['PondLength']; ?>" oninput="calculatePondDimension()"> 
</div>

<div class="col-md-2">
গভীরতা:
 <input type="text" id="PondDepth" name="PondDepth" placeholder="" class="form-control" value="<?php echo $result1['PondDepth']; ?>" oninput="calculatePondDimension()"> 
</div>

<div class="col-md-2">
প্রস্থ:
<input type="text" id="PondWidth" name="PondWidth" placeholder="" class="form-control" value="<?php echo $result1['PondWidth']; ?>" oninput="calculatePondDimension()">
</div>

<div class="col-md-2">
আয়তন:
<input type="text" id="PondDimension" name="PondDimension" placeholder="" class="form-control align-left" value="<?php echo $result1['PondDimension']; ?>" readonly ></textarea>
</div> 
</div>
<div class="space"></div>
 
<div class="row form-group">                            
<div class="col-md-3"><label for="text-input" class=" form-control-label">মৎস্য চাষের উপযুক্ততা:<span style="color: red">*</span></label></div>                             
 
<div class="col-md-3">

<select name="SuitableFishery" class="form-control">
    <option value="">নির্বাচন করুন</option>
    <option value="1" <?php if ($result1['SuitableFishery'] == 1) echo 'selected'; ?>>উপযুক্ত</option>
    <option value="0" <?php if ($result1['SuitableFishery'] == 0) echo 'selected'; ?>>অনুপযুক্ত</option>
</select>

</div>
</div>

<div class="space"></div>

<div class="row form-group">

<div class="col-md-3">

 <label for="text-input" class="form-control-label">অনুপযুক্ত হলে করণীয়:</label></div>
 <div class="col-md-8">  
 <textarea type="text" id="ToDo" name="ToDo" placeholder="" class="form-control align-left"><?php echo $result1['ToDo']; ?></textarea>
<small class="form-text text-muted"></small></div> 
</div>

<div class="space"></div>

<div class="row form-group">
 <div class="col-md-3"><label for="text-input" class=" form-control-label">মন্তব্য:</label></div>
<div class="col-md-8">  
<textarea type="text" id="Comments" name="Comments" placeholder="" class="form-control align-left"><?php echo $result1['Comments']; ?></textarea>
<small class="form-text text-muted"></small></div> 
</div>                            
                        
<div class="space"></div>

<div class="row form-group">    
<div class="col-md-2"><label for="form-label" >ছবি নির্বাচন করুন: <span style="color: red">*</span></label></div>
<div class="col-md-4">ছবি আপলোড করুন: <span style="color: red">*</span><input type="file" id="Image1" class="form-control rounded-0 border-info formFileMultiple" name="Image1">
<small class="form-text text-muted"><a href="<?php echo $result1['Image1']; ?>" target="_blank">View Image 1</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image1Caption" name="Image1Caption" class="form-control" value="<?php echo $result1['Image1Caption']; ?>" ></div>
</div>

<div class="space"></div>
<div class="row form-group"> 
<div class="col-md-2"><label class="form-label">&nbsp;</label></div>
<div class="col-md-4">ছবি আপলোড করুন: <span style="color: red">*</span><input type="file" id="Image2" class="form-control rounded-0 border-info formFileMultiple" name="Image2">
<small class="form-text text-muted"><a href="<?php echo $result1['Image2']; ?>" target="_blank">View Image 2</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image2Caption" name="Image2Caption" class="form-control" value="<?php echo $result1['Image2Caption']; ?>" ></div>
</div>
<div class="space"></div>

<div class="row form-group">   
<div class="col-md-2"><label class="form-label">&nbsp; </label></div>
<div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image3" class="form-control rounded-0 border-info formFileMultiple" name="Image3">
<small class="form-text text-muted"><a href="<?php echo $result1['Image3']; ?>" target="_blank">View Image 3</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image3Caption" name="Image3Caption" class="form-control" value="<?php echo $result1['Image3Caption']; ?>" ></div>
</div>
<div class="space"></div>

<div class="row form-group">
<div class="col-md-2">&nbsp; </div>
<div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image4" class="form-control rounded-0 border-info formFileMultiple" name="Image4">
<small class="form-text text-muted"><a href="<?php echo $result1['Image4']; ?>" target="_blank">View Image 4</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image4Caption" name="Image4Caption" class="form-control" value="<?php echo $result1['Image4Caption']; ?>" ></div>
</div>
<div class="space"></div>

<div class="col-md-2"></div><div class="col-md-4">ছবি আপলোড করুন: <input type="file" id="Image5" class="form-control rounded-0 border-info formFileMultiple" name="Image5">
<small class="form-text text-muted"><a href="<?php echo $result1['Image5']; ?>" target="_blank">View Image 5</a></small></div>
<div class="col-md-4">ছবির ক্যাপশন লিখুন: <input type="text" id="Image5Caption" name="Image5Caption" class="form-control" value="<?php echo $result1['Image5Caption']; ?>" ></div>
<div class="space"></div>               

                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Update Now
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>

    <!-- Right Panel -->


<?php include 'js_master.php';?>

<script>
    function calculatePondDimension() {
        var length = document.getElementById('PondLength').value;
        var depth = document.getElementById('PondDepth').value;
        var width = document.getElementById('PondWidth').value;
        var dimension = length * depth * width;
        document.getElementById('PondDimension').value = dimension;
    }
</script>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>