<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="bn">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Upazila Combined Office Building Project</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>
    <style>
	.space {
	width:100%; 
	height:15px;
	}
	.col-md-3 {
		font-size:12px !important;
	}
	/*.background {
		border:1px solid #ccc; padding:5px;
		background-color:#F8F8FA;
	} */
	.innara {
		font-size:14px;
		color:#000000;
		text-decoration:underline;
	}
	
	</style>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
                


        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Add New Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="insert1.php" method="post" enctype="multipart/form-data" class="form-horizontal">


                        <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php }
		$query = mysqli_query($conn, "SELECT * from tbl_court where ID=".$_GET['id']) or die(mysqli_error($conn));
       $result1=mysqli_fetch_array($query);
		
		?>
                        
                        
 <span style="color:#8247b3; font-weight:500;"><?php echo $result['AssetTypeFull'];?></span><br><br>
                        <div class="row form-group">
                       
                        <div class="col-md-3"><label for="text-input" class=" form-control-label">উপজেলা নির্বাচন করুন:</label></div>
                            <div class="col-md-4"><select id="UpazilaID" name="UpazilaID" style="width:360px; height:40px;" required>
                            <?php
							$result = mysqli_query($conn, "SELECT * from tbl_upazila where UserID='".$_SESSION["UserID"]."'")or die(mysqli_error($conn));
	    					while($row=mysqli_fetch_array($result)) {
							?>
                            <option value="<?php echo $row['ID']?>"><?php echo $row['UpazilaName'];?></option>
                            <?php } ?>
                            </select></div> 
                            
                           <div class="space"></div>
                           
                           <div class="col-md-3"><label for="text-input" class=" form-control-label">উপজেলায় অবস্থিত কোর্ট ভবনের জমির পরিমান:</label></div>
                            <div class="col-md-4"><input type="text" id="LandSize" name="LandSize" placeholder="" class="form-control"  
                            value="<?php echo $result1['LandSize'];?>" readonly><small class="form-text text-muted"></small></div> 
                            
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">জমির মালিকানার তথ্য:</label></div>
                            <div class="col-md-4"><input type="text" id="OwenershipInfo" name="OwenershipInfo" placeholder="" class="form-control" value="<?php echo $result1['OwenershipInfo'];?>" readonly><small class="form-text text-muted"></small></div> 
                            <div class="col-md-4"><?php if($result1['OwenershipInfoFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['OwenershipInfoFile'];?>" target="_blank">Download File</a> <?php };?></div>
                            
                            
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">জমির দাগ এবং খতিয়ান:</label></div>
                            <div class="col-md-4"><input type="text" id="DagKhatiyan" name="DagKhatiyan" placeholder="" class="form-control" value="<?php echo $result1['DagKhatiyan'];?>" readonly><small class="form-text text-muted"></small></div> 
                             <div class="col-md-4"><?php if($result1['DagKhatiyanFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['DagKhatiyanFile'];?>" target="_blank">Download File</a> <?php };?></div>
                                                        
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">জমির কর প্রদানের তথ্য এবং কর প্রদানের রশিদ:</label></div>
                            <div class="col-md-4"><input type="text" id="LandTaxInfo" name="LandTaxInfo" placeholder="" class="form-control" value="<?php echo $result1['LandTaxInfo'];?>" readonly><small class="form-text text-muted"></small></div> 
                            <div class="col-md-4"><?php if($result1['LandTaxInfoFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['LandTaxInfoFile'];?>" target="_blank">Download File</a> <?php };?></div>
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">উক্ত জমিতে বর্তমানে ভবন ছাড়া অন্য স্থাপনার বিবরন:</label></div>
                            <div class="col-md-4"><input type="text" id="OtherInstallationInfo" name="OtherInstallationInfo" placeholder="" class="form-control" value="<?php echo $result1['OtherInstallationInfo'];?>" readonly><small class="form-text text-muted"></small></div> 

                            
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">উক্ত জায়গার ডিজিটাল সার্ভে রিপোর্ট:</label></div>
                             <div class="col-md-4"><input type="text" id="SurveyReport" name="SurveyReport" placeholder="" class="form-control" value="<?php echo $result1['SurveyReport'];?>" readonly><small class="form-text text-muted"></small></div>
                            <div class="col-md-4"><?php if($result1['SurveyReportFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['SurveyReportFile'];?>" target="_blank">Download File</a> <?php };?></div>
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">বর্তমানে ভবন ব্যবহারকারী অফিসসমূহের নাম:</label></div>
                            <div class="col-md-4"><input type="text" id="OtherOfficeNames" name="OtherOfficeNames" placeholder="" class="form-control" value="<?php echo $result1['OtherOfficeNames'];?>" readonly><small class="form-text text-muted"></small></div>
                            
                            
                            
                         <div class="space"></div>
                            <div class="background">
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">উক্ত ভবন অপসারন করে সমন্বিত অফিস ভবন করা হলে উপজেলা পর্যায়ে যে সব অফিসের চাহিদা আছে তার নামের তালিকা এবং কর্মকর্তা কর্মচারির সংখ্যা:</label></div>
                            <div class="col-md-4"><textarea type="text" id="OtherOfficeDemand" name="OtherOfficeDemand" placeholder="" class="form-control" readonly><?php echo $result1['OtherOfficeDemand'];?></textarea></div>
                            <div class="col-md-4"><?php if($result1['OtherOfficeDemandFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['OtherOfficeDemandFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            
                            </div>
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">ভবনের ছবি:</label></div>
                            <div class="col-md-4"><input type="file" id="BuildingPhotoFile" name="BuildingPhotoFile" placeholder="" class="form-control" required><small class="form-text text-muted"></small></div>
                            <!--<div class="col-md-4"><input type="file" id="code_no_bn" name="file" placeholder="" class="form-control" required><small class="form-text text-muted"></small></div>-->
                            
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">ভবনের নির্মান সাল:</label></div>
                            <div class="col-md-4"><input type="text" id="EstablishYear" name="EstablishYear" placeholder="" class="form-control" value="<?php echo $result1['EstablishYear'];?>" readonly><small class="form-text text-muted"></small></div>

                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">ভবনের প্লিন্থ এরিয়া:</label></div>
                             <div class="col-md-4"><input type="text" id="PlinthArea" name="PlinthArea" placeholder="" class="form-control" value="<?php echo $result1['PlinthArea'];?>" readonly><small class="form-text text-muted"></small></div>
                            
                            
                            <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">ভবনের ফ্লোর এরিয়া:</label></div>
                             <div class="col-md-4"><input type="text" id="FloorArea" name="FloorArea" placeholder="" class="form-control" value="<?php echo $result1['FloorArea'];?>" readonly><small class="form-text text-muted"></small></div>

                            
                            
                            
                           <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">ইউএনএর মতামত সহ সংযুক্তি:</label></div>
                            <div class="col-md-4"><input type="text" id="UnoComment" name="UnoComment" placeholder="" class="form-control" value="<?php echo $result1['UnoComment'];?>" readonly><small class="form-text text-muted"></small></div>
                            <div class="col-md-4"><?php if($result1['UnoCommentFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['UnoCommentFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">উপজেলা পরিষদ অঙ্গনে সমন্বিত ভবন নির্মান করার মত ফাকা জায়গা আছে কিনা:</label></div>
                            <div class="col-md-4"><input type="text" id="EmptySpace" name="EmptySpace" placeholder="" class="form-control" value="<?php echo $result1['EmptySpace'];?>" readonly><small class="form-text text-muted"></small></div>
                            <div class="col-md-4"><?php if($result1['EmptySpaceFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['EmptySpaceFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            
                            
                            
                            
                            
                             <div class="space"></div>
                            
                            <div class="col-md-3"><label for="text-input" class=" form-control-label">জেলা জজ মহোদয়ের মন্তব্য:</label></div>
                            <div class="col-md-4"><input type="text" id="DistrictJudgeComment" name="DistrictJudgeComment" placeholder="" class="form-control" value="<?php echo $result1['DistrictJudgeComment'];?>" readonly><small class="form-text text-muted"></small></div>
                            
                            <div class="col-md-4"><?php if($result1['DistrictJudgeCommentFile']) { ?> 
                            <a class='innara' href="documents/court/<?php echo $result1['DistrictJudgeCommentFile'];?>" target="_blank">Download File</a> <?php };?></div> 
                            

                   </div> 
                </div>
                <!--<div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Submit
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>-->
                </form>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
