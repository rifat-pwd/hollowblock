<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (ERP) for Co-ordination</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>
        
        

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
          <?php 
		  $query = mysqli_query($conn, "SELECT * from tbl_upazila where ID=".$_GET['id']) or die(mysqli_error($conn));
       	   $result1=mysqli_fetch_array($query);
		  ?>      


        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Edit Upazila Information</strong> 
                </div>
                <div class="card-body card-block">
                    <form action="update2.php" method="post" enctype="multipart/form-data" class="form-horizontal">
                    <input type="hidden" name="UpazilaID" value="<?php echo $_GET['id'];?>">


                        <?php if(isset($_GET['msg_success'])){?>
                        <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <span class="badge badge-pill badge-success"></span> <?php echo $_GET['msg_success'];?>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>

        <?php }
		//$query = mysqli_query($conn, "SELECT * from tbl_assets where ID=".$_GET['asset']) or die(mysqli_error($conn));
        //$result=mysqli_fetch_array($query);
		
		?>
                        
                        
 <span style="color:#8247b3; font-weight:500;"><?php //echo $result['AssetTypeFull'];?></span><br><br>
                        <div class="row form-group">
                        <div class="col col-md-3"><label for="text-input" class=" form-control-label">Upazila Name In Bangla:<span style="color: red">*</span></label></div>
                            <div class="col-12 col-md-4"><input type="text" id="UpazilaNameBn" name="UpazilaNameBn" placeholder="" class="form-control" value="<?php echo $result1['UpazilaNameBn'];?>" required><small class="form-text text-muted"></small></div> <div class="col col-md-3"></div>
                            
                            
                        
                         <div class="col col-md-3"><label for="text-input" class=" form-control-label">Upazila Name In English:<span style="color: red">*</span></label></div>
                            <div class="col-12 col-md-4"><input type="text" id="UpazilaName" name="UpazilaName" placeholder="" value="<?php echo $result1['UpazilaName'];?>" class="form-control" required><small class="form-text text-muted"></small></div> <div class="col col-md-6"></div>
                            
                            
                            </div>                       

 
                    
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary btn-sm" name="add_economic_code" style="float: right; border-radius: 5px"> 
                        <i class="fa fa-dot-circle-o"></i> Update Now
                    </button>
                    <!-- <button type="reset" class="btn btn-danger btn-sm">
                        <i class="fa fa-ban"></i> Reset
                    </button> -->
                </div>
                </form>
            </div>
            
        </div>


        
    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
