<?php 
session_start();
if ($_SESSION['flag'] == 'ok') {
    include("config/connection.php");
    header("Content-type: application/vnd.ms-excel; name='excel'");
    header("Content-Disposition: attachment; filename=tree-info_all.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (ERP) for Co-ordination</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">
</head>

<body>

    <div id="right-panel" class="right-panel">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title" style="color:green;">View Information</strong> 
                </div>
                <div class="card-body">
                    <table style="font-size:12px; width:1200px; border:1px solid #000;" border="1">
                        <thead>
                            <tr>
                            <th rowspan="2">ক্রম</th>
                                    <th rowspan="2">রোপনের স্থান</th>
                                    <th colspan="2">গাছের ধরণ</th> 
                                    <th rowspan="2">সংখ্যা</th>
                                    <th rowspan="2">পিচ তৈরী</th>
                                    <th rowspan="2">চারা সংগ্রহ</th>
                                    <th rowspan="2">চারা রোপন</th>
                                    <th rowspan="2">৩০ সেপ্টেম্বর /৩০ ডিসেম্বর/৩০ মার্চে রোপিত গাছের সংখ্যা </th>
                                    <th rowspan="2">মন্তব্য</th>
                            </tr>
                            <tr>
                            
                            </tr>
                            
                        </thead>
                        <tbody>
                            <?php 
                            $sl = 0;
                            $query = "SELECT tbl_tree.*, hrtoffice.OfficeName
                                      FROM tbl_tree
                                      INNER JOIN hrtoffice ON hrtoffice.OfficeID = tbl_tree.OfficeID
                                      ORDER BY hrtoffice.OfficeName ASC";
                            $query1 = mysqli_query($conn, $query) or die(mysqli_error($conn));
                            while ($row = mysqli_fetch_array($query1)) {
                                $sl++; 
                                echo "<tr>";
                                echo "<td>".$sl."</td>";
                                echo "<td>".$row['PlaceName']."</td>";
                                echo "<td>".$row['TreeType']."</td>";
                                echo "<td>".$row['TreeVariant']."</td>";
                                echo "<td>".$row['TreeNo']."</td>";
                                echo "<td>".$row['PitchPrepare']."</td>";
                                echo "<td>".$row['SeedCollect']."</td>";
                                echo "<td>".$row['SeedPlant']."</td>";
                                echo "<td>".$row['PlantedNo']."</td>";
                                echo "<td>".$row['Comments']."</td>";
                                /*echo "<td><a href='view_tree1.php?id=".$row['ID']."' target='_blank'>View Images</a></td>";*/
                                echo "</tr>";
                            } 
                            ?>        
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php include 'js_master.php';?>

</body>

</html>

<?php 
} elseif ($_SESSION["flag"] == "error_pass") {
    $msg = "The password is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "captcha") {
    $msg = "Your given number is incorrect!";
    header("Location: index.php?msg=".$msg);
} elseif ($_SESSION["flag"] == "error_username") {
    $msg = "The username is incorrect!";
    header("Location: index.php?msg=".$msg);
} else {
    $msg = "The username and password are incorrect!";
    header("Location: index.php?msg=".$msg);
}
?>
