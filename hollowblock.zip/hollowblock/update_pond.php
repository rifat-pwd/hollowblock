<?php
session_start();
include("config/connection.php");

$query1="SELECT * from tbl_pond where ID=".$_POST['ID'];
$query_get = mysqli_query($conn,$query1) or die(mysqli_error($conn));
$result_get=mysqli_fetch_array($query_get);


if($_FILES['Image1']['name'])
{
$filepath1=$result_get['Image1'];
unlink($filepath1);
$imageName1 =$_FILES['Image1']['name'];
$imageTmpName = $_FILES['Image1']['tmp_name'];
$fileType = $_FILES['Image1']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/pond/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file1="documents/pond/".$imageName1; 
}
else $target_file1=$result_get['Image1'];
}
else 
{
	$target_file1=$result_get['Image1'];
}



if($_FILES['Image2']['name'])
{
$filepath2=$result_get['Image2'];
unlink($filepath2);
$imageName1 =$_FILES['Image2']['name'];
$imageTmpName = $_FILES['Image2']['tmp_name'];
$fileType = $_FILES['Image2']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/pond/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file2="documents/pond/".$imageName1; 
}
else $target_file2=$result_get['Image2'];
}
else 
{
	$target_file2=$result_get['Image2'];
}



if($_FILES['Image3']['name'])
{
$filepath3=$result_get['Image3'];
unlink($filepath3);
$imageName1 =$_FILES['Image3']['name'];
$imageTmpName = $_FILES['Image3']['tmp_name'];
$fileType = $_FILES['Image3']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/pond/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file3="documents/pond/".$imageName1; 
}
else $target_file3=$result_get['Image3'];
}
else 
{
	$target_file3=$result_get['Image3'];
}



if($_FILES['Image4']['name'])
{
$filepath4=$result_get['Image4'];
unlink($filepath4);
$imageName1 =$_FILES['Image4']['name'];
$imageTmpName = $_FILES['Image4']['tmp_name'];
$fileType = $_FILES['Image4']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/pond/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file4="documents/pond/".$imageName1; 
}
else $target_file4=$result_get['Image4'];
}
else 
{
	$target_file4=$result_get['Image4'];
}



if($_FILES['Image5']['name'])
{
$filepath5=$result_get['Image5'];
unlink($filepath5);
$imageName1 =$_FILES['Image5']['name'];
$imageTmpName = $_FILES['Image5']['tmp_name'];
$fileType = $_FILES['Image5']['type'];
$fileExt = explode('.', $imageName1);
$fileActualExt = strtolower(end($fileExt));
$allowed = array('doc','docx','pdf','jpg','jpeg','png');
if (in_array($fileActualExt, $allowed)) {
$directory = 'documents/pond/';
$result = move_uploaded_file($imageTmpName, $directory.$imageName1);
$target_file5="documents/pond/".$imageName1; 
}
else $target_file5=$result_get['Image5'];
}
else 
{
	$target_file5=$result_get['Image5'];
}


$query="UPDATE tbl_pond SET
		PondName='".$_POST['PondName']."',
		MouzaName='".$_POST['MouzaName']."',
		KhatianNo='".$_POST['KhatianNo']."',
		DagNo='".$_POST['DagNo']."',
		LandAmount='".$_POST['LandAmount']."',
		PondLength='".$_POST['PondLength']."',
		PondDepth='".$_POST['PondDepth']."',
		PondWidth='".$_POST['PondWidth']."',
		PondDimension='".$_POST['PondDimension']."',
		SuitableFishery='".$_POST['SuitableFishery']."',
		Comments='".$_POST['Comments']."',
		ToDo='".$_POST['ToDo']."',
		Image1Caption='".$_POST['Image1Caption']."',
		Image2Caption='".$_POST['Image2Caption']."',
		Image3Caption='".$_POST['Image3Caption']."',
		Image4Caption='".$_POST['Image4Caption']."',
		Image5Caption='".$_POST['Image5Caption']."',
		Image1='".$target_file1."',
		Image2='".$target_file2."',
		Image3='".$target_file3."',
		Image4='".$target_file4."',
		Image5='".$target_file5."'
		WHERE ID=".$_POST['ID'];
		
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));

if($result)
{
	header("Location: view_pond.php?msg=Information Updated Successfully");
}
?>