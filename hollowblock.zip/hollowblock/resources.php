<?php 
session_start();

if ($_SESSION['flag']=='ok') {

    include("config/connection.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Upazila Combined Office Building Project</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>
        
        

        <div class="breadcrumbs">
            <div class="col-sm-6">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?php include 'office_name.php';?></h1>
                    </div>
                </div>
            </div>
            
        </div>

        
            
         <div class="col-md-12">
                        <div class="card">
                            <div class="card-header"><strong>List of Upazila's Under Your Jurisdiction</strong>
                                <a href="add_resource.php" style="float:right; color:green; font-weight:bold;">Add New</a>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Upazila</th>
                                            <th>Name of Upazila (Bangla)</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
                    $query1 = mysqli_query($conn, "SELECT * from tbl_upazila where OfficeID=".$_SESSION['OfficeID']) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++; 
                        ?>
<tr>
<td><?php echo $sl; ?></td>
<td><?php echo $result1['UpazilaName'];?></td>
<td><?php echo $result1['UpazilaNameBn'];?></td>
<td><a href="edit_resources.php?id=<?php echo $result1['ID'];?>" style="font-size:15px; text-align:center; font-weight:bold;">Edit</a></td></tr>
                                    <?php } ?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

    <!-- Right Panel -->


    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>