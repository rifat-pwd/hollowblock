<?php 
		$result_office = mysqli_query($conn, "SELECT ".DBHR.".hrtoffice.OfficeName FROM ".DBHR.".hrtoffice 
								WHERE ".DBHR.".hrtoffice.OfficeID=".$_SESSION["OfficeID"])or die(mysqli_error($conn));
	    $row_office=mysqli_fetch_array($result_office);
		echo $row_office['OfficeName'];
	   ?>