<?php 
session_start();

if ($_SESSION['flag']=='ok') {
include("config/connection.php");

?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Enterprise Resource Planning (Co-ordination)</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>

</head>

<body>


    <?php include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <!--<div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>-->
        </div>

        <!-- content-start -->
<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Divitional Reports</strong>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>SL</th>
                                            <th>Name of Office</th>
                                            <th>Date of Completion</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
					<?php 
                    $sl = 0;
					$qur="SELECT tbl_workrecord.*, ".DBHR.".hrtoffice.OfficeName 
					from tbl_workrecord 
					INNER JOIN ".DBHR.".hrtoffice on tbl_workrecord.OfficeID=".DBHR.".hrtoffice.OfficeID
					GROUP BY tbl_workrecord.OfficeID";
                    $query1 = mysqli_query($conn,$qur) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['OfficeName']?></td>
<td><?php echo date("d/m/Y", strtotime($result1['CompletionDate']));?></td>
<td><a href="dengu_dashboard_by_division.php?officeid=<?php echo $result1['OfficeID'];?>" style="color:green; font-size:12px; text-align:center; font-weight:bold;">View Details</a></td></tr>
                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
