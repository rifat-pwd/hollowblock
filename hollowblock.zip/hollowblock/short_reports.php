<?php 
session_start();
if ($_SESSION['flag']=='ok') {
include("config/connection.php");
?>
<!doctype html>
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Database for Upazila Combined Office Building Project</title>
    <meta name="description" content="Human Resource Information System">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="assets/images/favicon.png">

    <?php include 'css_master.php';?>
    <style type="text/css">
	a { color:blue;
	text-decoration:underline; }
	</style>

</head>

<body>


    <?php //include 'sidebar.php';?>

  

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <?php include 'navbar.php';?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <!--<div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </div>
            </div>-->
        </div>

        <!-- content-start -->
<div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Reports Date:: <?php echo date('d-m-Y');?></strong>
                                 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="all_reports_excel.php" target="_blank">Export to Excel</a>
                            </div>
                            <div class="card-body">
                                <table  class="table table-striped table-bordered" style="font-size:10px; width:1200px;">
                                    <thead>
                                        <tr>
                                            <th>ক্রমিক</th>
                                            <th>অফিসের নাম</th>
                                            <th>উপজেলার নাম</th>
                                            <th>কোর্ট ভবনের জমির পরিমান</th>
                                            <th>উক্ত ভবন অপসারন করে সমন্বিত অফিস ভবন করা হলে উপজেলা পর্যায়ে যে সব অফিসের চাহিদা আছে তার নামের তালিকা এবং কর্মকর্তা কর্মচারির সংখ্যা:</th>
                                        </tr>
                                        
                                    </thead>
                                    <tbody>
					<?php 
					
					$user_id = array('1', '2','3', '4', '5','6', '7');
					
                    $sl = 0;
					$qur="SELECT tbl_court.*, tbl_upazila.UpazilaNameBn, hrtoffice.OfficeName, hrtoffice.OfficeNameBn
					from tbl_court 
					INNER JOIN tbl_upazila on tbl_upazila.ID=tbl_court.UpazilaID
					INNER JOIN hrtoffice on hrtoffice.OfficeID=tbl_court.OfficeID
					ORDER BY hrtoffice.OfficeName,tbl_upazila.OfficeID";
                    $query1 = mysqli_query($conn,$qur) or die(mysqli_error($conn));
                    while($result1=mysqli_fetch_array($query1)){
                        $sl++;
                        ?>
<tr>
<td><?=$sl?></td>
<td><?=$result1['OfficeNameBn']?></td>
<td><?=$result1['UpazilaNameBn']?></td>
<td><?=$result1['LandSize']?></td>
<td><?php echo $result1['OtherOfficeDemand']."<br>"; if($result1['OtherOfficeDemandFile']) {?> <a href="documents/court/<?php echo $result1['OtherOfficeDemandFile'];?>" target="_blank">ডাউনলোড</a><?php }?></td>
</tr>


<?php /* 
$qur2=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=2 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res2=mysqli_fetch_array($qur2);
if($res2) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res2['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur3=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=3 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res3=mysqli_fetch_array($qur3);
if($res3) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res3['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur4=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=4 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res4=mysqli_fetch_array($qur4);
if($res4) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res4['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>

<?php 
$qur5=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=5 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res5=mysqli_fetch_array($qur5);
if($res5) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res5['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur6=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=6 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res6=mysqli_fetch_array($qur6);
if($res6) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res6['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } ?>


<?php 
$qur7=mysqli_query($conn,"SELECT * from tbl_workrecord WHERE AssetTypeID=7 AND OfficeID=".$result1['OfficeID']." order by OrderID ASC") or die(mysqli_error($conn));
$res7=mysqli_fetch_array($qur7);
if($res7) {
?>
<td>Yes</td>
<td><?php echo date ('d-m-Y',strtotime($res7['CompletionDate']));?></td>
<?php } else { ?>
<td>&nbsp;</td>
<td>&nbsp;</td>
<?php } */ ?>



</tr>

                                    <?php }?>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    
    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    <?php include 'js_master.php';?>

</body>

</html>

<?php }elseif($_SESSION["flag"] == "error_pass")
    {
      $msg = "The password is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "captcha") {
     $msg = "Your given number is incorrect!";
        header("Location: index.php?msg=".$msg);

    }elseif ($_SESSION["flag"] == "error_username") {
     $msg = "The username is incorrect!";
        header("Location: index.php?msg=".$msg);

      }else {
        $msg = "The username and password are incorrect!";
        header("Location: index.php?msg=".$msg);
      }
    ?>
