<?php
session_start();
include("config/connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Images</title>
    <style>
        .image-container {
            display: flex;
            flex-wrap: wrap;
        }

        .image-wrapper {
            width: calc(32% - 8px);
            margin-right: 20px; 
            margin-bottom: 20px;
            box-sizing: border-box;
            position: relative;
        }

        .image-wrapper img {
            width: 100%;
            height: auto;
            margin-bottom: 10px;
        }

        .image-wrapper .image-name {
            text-align: center;
            margin-top: 5px;
        }

        .image-wrapper .image-name a {
            text-decoration: none;
            color: #8a2be2;
            display: block;
            padding: 5px 0; 
            background-color: #f0f0f0;
            border-radius: 5px;
        }

        .image-wrapper .image-name a:hover {
            background-color: #e0e0e0;
        }

        .image-wrapper .image-label {
            text-align: center;
        }

    </style>
</head>
<body>

<?php
if(isset($_GET['id'])) {

    $id = $_GET['id'];
    $query = mysqli_query($conn, "SELECT * FROM tbl_pond WHERE ID = $id");
    $row = mysqli_fetch_array($query);

    echo "<h4>Images of  :: ".$row['PondName']."</h4>";
    echo '<div class="image-container">';
    for ($imgNum = 1; $imgNum <= 5; $imgNum++) {
        if (!empty($row['Image'.$imgNum])) {
            $imageName = basename($row['Image' .$imgNum]);
            echo '<div class="image-wrapper">';
            echo '<a href="' . $row['Image' .$imgNum] . '" target="_blank" onclick="window.open(this.href, \'_blank\'); return false;">'; 
            echo '<img src="' . $row['Image' .$imgNum] . '" style="height:200px;">';
            echo '</a>';
            echo '<p class="image-name"><a href="' . $row['Image' .$imgNum] . '" download>' . $row['Image' .$imgNum.'Caption'] . '</a></p>';
            //echo '<div class="image-label">Image-' .$imgNum.'</div>';
            echo '</div>';
        }
    }
    echo '</div>';
} else {
    header("Location: view_pond.php");
    exit();
}
?>

</body>
</html>